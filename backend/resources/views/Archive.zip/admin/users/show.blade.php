@extends('admin.layouts.app')

@section('title', __('admin.users.details_title'))
@section('page-title', __('admin.users.details_title'))

@section('content')
<div class="space-y-6">
    <!-- User Info -->
    <div class="bg-white rounded-xl shadow-md p-6">
        <div class="flex items-start justify-between mb-6">
            <div class="flex items-center gap-4">
                <img src="{{ $user->avatar ? asset('storage/' . $user->avatar) : 'https://ui-avatars.com/api/?name=' . urlencode($user->name) }}"
                     alt="{{ $user->name }}"
                     class="w-20 h-20 rounded-full border-4 border-secondary">
                <div>
                    <h2 class="text-2xl font-bold text-primary">{{ $user->name }}</h2>
                    <p class="text-gray-600">{{ $user->email }}</p>
                    <div class="flex items-center gap-2 mt-2">
                        <span class="px-3 py-1 rounded-full text-xs font-semibold
                            {{ $user->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">
                            {{ $user->is_active ? __('admin.active') : __('admin.inactive') }}
                        </span>
                        @if($user->is_verified)
                            <span class="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                                <i class="fas fa-check-circle"></i> {{ __('admin.verified') }}
                            </span>
                        @endif
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-2">
                <form action="{{ route('admin.users.toggle-status', $user->id) }}" method="POST">
                    @csrf
                    <button type="submit" class="bg-yellow-50 text-yellow-600 hover:bg-yellow-100 px-4 py-2 rounded-lg transition">
                        <i class="fas fa-power-off"></i>
                        {{ $user->is_active ? __('admin.disable') : __('admin.enable') }}
                    </button>
                </form>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="bg-blue-50 p-4 rounded-lg">
                <p class="text-sm text-gray-600 mb-1">{{ __('admin.users.stats.total_ads') }}</p>
                <p class="text-2xl font-bold text-primary">{{ $user->ads_count }}</p>
            </div>
            <div class="bg-green-50 p-4 rounded-lg">
                <p class="text-sm text-gray-600 mb-1">{{ __('admin.users.stats.subscriptions') }}</p>
                <p class="text-2xl font-bold text-primary">{{ $user->subscriptions_count }}</p>
            </div>
            <div class="bg-yellow-50 p-4 rounded-lg">
                <p class="text-sm text-gray-600 mb-1">{{ __('admin.users.stats.payments') }}</p>
                <p class="text-2xl font-bold text-primary">{{ $user->payments_count }}</p>
            </div>
        </div>

        @if($user->is_verified)
        <div class="mt-6 bg-gray-50 border border-gray-200 rounded-lg p-4">
            <h3 class="text-lg font-bold text-primary mb-4 flex items-center gap-2">
                <i class="fas fa-briefcase"></i> {{ __('admin.users.verified_business_data') }}
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-800">
                <div>
                    <p class="font-semibold text-gray-700">{{ __('admin.verification.business.name') }}</p>
                    <p>{{ $user->business_name ?? '-' }}</p>
                </div>
                <div>
                    <p class="font-semibold text-gray-700">{{ __('admin.verification.business.type') }}</p>
                    <p>{{ $user->business_type ?? '-' }}</p>
                </div>
                <div>
                    <p class="font-semibold text-gray-700">{{ __('admin.users.business_owner') }}</p>
                    <p>{{ $user->business_owner ?? '-' }}</p>
                </div>
                <div>
                    <p class="font-semibold text-gray-700">{{ __('admin.verification.business.phone') }}</p>
                    <p>{{ $user->business_phone ?? '-' }}</p>
                </div>
                <div class="md:col-span-2">
                    <p class="font-semibold text-gray-700">{{ __('admin.verification.business.address') }}</p>
                    <p>{{ $user->business_address ?? '-' }}</p>
                </div>
                <div>
                    <p class="font-semibold text-gray-700">{{ __('admin.users.contact_links') }}</p>
                    <div class="flex items-center gap-3 mt-1 text-primary">
                        @if($user->instagram_url)
                            <a href="{{ $user->instagram_url }}" target="_blank" class="text-xl hover:text-secondary"><i class="fab fa-instagram"></i></a>
                        @endif
                        @if($user->facebook_url)
                            <a href="{{ $user->facebook_url }}" target="_blank" class="text-xl hover:text-secondary"><i class="fab fa-facebook"></i></a>
                        @endif
                        @if($user->website_url)
                            <a href="{{ $user->website_url }}" target="_blank" class="text-xl hover:text-secondary"><i class="fas fa-globe"></i></a>
                        @endif
                        @if(!$user->instagram_url && !$user->facebook_url && !$user->website_url)
                            <span class="text-gray-500 text-sm">{{ __('admin.verification.contact.none') }}</span>
                        @endif
                    </div>
                </div>
                <div>
                    <p class="font-semibold text-gray-700">{{ __('admin.users.storefront_image') }}</p>
                    @if($user->storefront_image_path)
                        <a href="{{ asset('storage/' . $user->storefront_image_path) }}" target="_blank" class="block mt-2">
                            <img src="{{ asset('storage/' . $user->storefront_image_path) }}" alt="{{ __('admin.users.storefront_image') }}" class="w-full max-w-xs rounded-lg border">
                        </a>
                    @else
                        <span class="text-gray-500 text-sm">{{ __('admin.users.no_storefront') }}</span>
                    @endif
                </div>
            </div>
        </div>
        @endif
    </div>

    <!-- Recent Ads -->
    <div class="bg-white rounded-xl shadow-md p-6">
        <h3 class="text-xl font-bold text-primary mb-6">{{ __('admin.user_ads') }}</h3>

        @if($user->ads->count() > 0)
            <div class="space-y-3">
                @foreach($user->ads as $ad)
                    <a href="{{ route('admin.ads.show', $ad->uid) }}" class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                        <div class="flex-1">
                            <h4 class="font-semibold text-gray-800">{{ $ad->title }}</h4>
                            <p class="text-xs text-gray-500">
                                {{ $ad->category->name_ar }} • {{ $ad->created_at->diffForHumans() }}
                            </p>
                        </div>
                        <span class="px-3 py-1 rounded-full text-xs font-semibold
                            {{ $ad->status === 'active' ? 'bg-green-100 text-green-700' :
                               ($ad->status === 'pending' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700') }}">
                            {{ __('admin.' . $ad->status) }}
                        </span>
                    </a>
                @endforeach
            </div>
        @else
            <p class="text-gray-500 text-center py-8">{{ __('admin.no_ads') }}</p>
        @endif
    </div>
</div>
@endsection

