@extends('admin.layouts.app')

@section('title', __('admin.notifications.send_title'))
@section('page-title', __('admin.notifications.send_title'))

@section('content')
<div class="max-w-4xl mx-auto space-y-6">
    @if(session('success'))
        <div class="p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">
            <i class="fas fa-check-circle ml-2"></i> {{ session('success') }}
        </div>
    @endif

    @if($errors->any())
        <div class="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            <ul class="list-disc list-inside space-y-1">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="bg-white rounded-xl shadow-md p-6 space-y-6">
        <form action="{{ route('admin.notifications.store') }}" method="POST" class="space-y-6">
            @csrf

            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.notifications.title') }}</label>
                <input type="text" name="title" value="{{ old('title') }}" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary">
            </div>

            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.notifications.message') }}</label>
                <textarea name="message" rows="4" required
                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary">{{ old('message') }}</textarea>
            </div>

            <div class="space-y-3">
                <p class="text-sm font-semibold text-gray-700">{{ __('admin.notifications.target') }}</p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <label class="flex items-center gap-2 border rounded-lg p-3">
                        <input type="radio" name="target_type" value="all" {{ old('target_type', 'all') === 'all' ? 'checked' : '' }}>
                        <span>{{ __('admin.notifications.all_users') }}</span>
                    </label>
                    <label class="flex items-center gap-2 border rounded-lg p-3">
                        <input type="radio" name="target_type" value="verified" {{ old('target_type') === 'verified' ? 'checked' : '' }}>
                        <span>{{ __('admin.notifications.verified_users') }}</span>
                    </label>
                    <label class="flex items-center gap-2 border rounded-lg p-3">
                        <input type="radio" name="target_type" value="unverified" {{ old('target_type') === 'unverified' ? 'checked' : '' }}>
                        <span>{{ __('admin.notifications.unverified_users') }}</span>
                    </label>
                    <label class="flex items-center gap-2 border rounded-lg p-3">
                        <input type="radio" name="target_type" value="date_range" {{ old('target_type') === 'date_range' ? 'checked' : '' }}>
                        <span>{{ __('admin.notifications.date_range') }}</span>
                    </label>
                    <label class="flex items-center gap-2 border rounded-lg p-3">
                        <input type="radio" name="target_type" value="selected" {{ old('target_type') === 'selected' ? 'checked' : '' }}>
                        <span>{{ __('admin.notifications.selected_users') }}</span>
                    </label>
                </div>
            </div>

            <div id="dateRangeBox" class="{{ old('target_type') === 'date_range' ? '' : 'hidden' }} grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.notifications.from_date') }}</label>
                    <input type="date" name="from_date" value="{{ old('from_date') }}"
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.notifications.to_date') }}</label>
                    <input type="date" name="to_date" value="{{ old('to_date') }}"
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary">
                </div>
            </div>

            <div id="selectedUsersBox" class="{{ old('target_type') === 'selected' ? '' : 'hidden' }} space-y-2">
                <label class="block text-sm font-semibold text-gray-700">
                    {{ __('admin.notifications.user_ids_label') }}
                </label>
                <textarea name="user_ids" rows="2"
                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary"
                          placeholder="{{ __('admin.notifications.user_ids_help') }}">{{ old('user_ids') }}</textarea>
                <p class="text-xs text-gray-500">{{ __('admin.notifications.user_ids_help') }}</p>

                <div class="border rounded-lg p-3">
                    <p class="text-sm font-semibold text-gray-700 mb-2">{{ __('admin.notifications.recent_users') }}</p>
                    <div class="flex flex-wrap gap-2 text-xs">
                        @foreach($recentUsers as $recent)
                            <span class="px-2 py-1 bg-gray-100 rounded border text-gray-700">
                                ID: {{ $recent->id }} • {{ $recent->name }} • {{ $recent->email }}
                            </span>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="flex items-center justify-end">
                <button type="submit" class="btn-primary px-6 py-3 rounded-lg font-bold">
                    <i class="fas fa-paper-plane ml-2"></i> {{ __('admin.notifications.send') }}
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const targetInputs = document.querySelectorAll('input[name="target_type"]');
    const dateBox = document.getElementById('dateRangeBox');
    const selectedBox = document.getElementById('selectedUsersBox');

    const toggleBoxes = () => {
        const val = document.querySelector('input[name="target_type"]:checked')?.value;
        dateBox.classList.toggle('hidden', val !== 'date_range');
        selectedBox.classList.toggle('hidden', val !== 'selected');
    };

    targetInputs.forEach(input => input.addEventListener('change', toggleBoxes));
});
</script>
@endsection

