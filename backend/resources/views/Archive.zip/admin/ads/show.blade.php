@extends('admin.layouts.app')

@section('title', __('admin.ads.show_page.title'))
@section('page-title', __('admin.ads.show_page.title'))

@section('content')
<div class="max-w-6xl mx-auto space-y-6">
    <!-- Ad Header -->
    <div class="bg-white rounded-xl shadow-md p-6">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h2 class="text-2xl font-bold text-primary mb-2">{{ $ad->title }}</h2>
                <p class="text-sm text-gray-600 mb-2">
                    <span class="font-semibold">UID:</span> {{ $ad->uid }}
                </p>
                <div class="flex items-center gap-3 mb-4">
                    <span class="px-4 py-2 rounded-full text-sm font-semibold
                        {{ $ad->status === 'active' ? 'bg-green-100 text-green-700' :
                           ($ad->status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                           ($ad->status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700')) }}">
                        {{ __('admin.' . $ad->status) ?? $ad->status }}
                    </span>

                    @if($ad->is_featured)
                        <span class="px-3 py-1 bg-secondary text-primary rounded-full text-xs font-bold">
                            <i class="fas fa-star"></i> {{ __('admin.ads.badges.featured') }}
                        </span>
                    @endif

                    @if($ad->is_urgent)
                        <span class="px-3 py-1 bg-red-500 text-white rounded-full text-xs font-bold">
                            <i class="fas fa-bolt"></i> {{ __('admin.ads.badges.urgent') }}
                        </span>
                    @endif
                    
                    @if($ad->pending_changes)
                        <span class="px-3 py-1 bg-orange-500 text-white rounded-full text-xs font-bold">
                            <i class="fas fa-edit"></i> {{ __('admin.ads.badges.pending_changes') }}
                        </span>
                    @endif
                </div>

                @if($ad->price)
                    <div class="text-3xl font-bold text-primary mb-4">
                        {{ format_price($ad->price, 0, $ad->currency) }}
                    </div>
                @endif
            </div>

            <div class="flex items-center gap-2">
                @if($ad->pending_changes)
                    <form action="{{ route('admin.ads.approve', $ad->uid) }}" method="POST">
                        @csrf
                        <button type="submit" class="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg transition">
                            <i class="fas fa-check ml-2"></i>
                            {{ __('admin.ads.show_page.approve_changes') }}
                        </button>
                    </form>
                    <form action="{{ route('admin.ads.reject', $ad->uid) }}" method="POST" class="inline" onsubmit="return confirm('{{ __('admin.ads.show_page.reject_changes_confirm') }}')">
                        @csrf
                        <input type="hidden" name="rejection_reason" value="{{ __('admin.ads.show_page.changes_rejected') }}">
                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg transition">
                            <i class="fas fa-times ml-2"></i>
                            {{ __('admin.ads.show_page.reject_changes') }}
                        </button>
                    </form>
                @elseif($ad->status === 'pending')
                    <form action="{{ route('admin.ads.approve', $ad->uid) }}" method="POST">
                        @csrf
                        <button type="submit" class="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg transition">
                            <i class="fas fa-check ml-2"></i>
                            {{ __('admin.ads.show_page.approve') }}
                        </button>
                    </form>
                @endif

                <form action="{{ route('admin.ads.toggle-featured', $ad->uid) }}" method="POST">
                    @csrf
                    <button type="submit" class="bg-yellow-50 text-yellow-600 hover:bg-yellow-100 px-4 py-3 rounded-lg transition">
                        <i class="fas fa-star ml-2"></i>
                        {{ $ad->is_featured ? __('admin.ads.show_page.toggle_featured_off') : __('admin.ads.show_page.toggle_featured_on') }}
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Pending Changes -->
    @if($ad->pending_changes)
        <div class="bg-orange-50 border border-orange-200 rounded-xl shadow-md p-6">
            <h3 class="text-xl font-bold text-orange-800 mb-4 flex items-center gap-2">
                <i class="fas fa-edit"></i>
                {{ __('admin.ads.show_page.pending_changes_title') }}
            </h3>
            
            <div class="space-y-4">
                @php $pending = $ad->pending_changes; @endphp
                
                @if(isset($pending['title']))
                    <div>
                        <h4 class="font-semibold text-gray-700 mb-2">{{ __('admin.ads.show_page.current_title') }}:</h4>
                        <p class="text-gray-600 mb-2">{{ $ad->title }}</p>
                        <h4 class="font-semibold text-orange-700 mb-2">{{ __('admin.ads.show_page.pending_title') }}:</h4>
                        <p class="text-orange-600">{{ $pending['title'] }}</p>
                    </div>
                @endif
                
                @if(isset($pending['description']))
                    <div>
                        <h4 class="font-semibold text-gray-700 mb-2">{{ __('admin.ads.show_page.current_description') }}:</h4>
                        <p class="text-gray-600 mb-2 whitespace-pre-wrap">{{ $ad->description }}</p>
                        <h4 class="font-semibold text-orange-700 mb-2">{{ __('admin.ads.show_page.pending_description') }}:</h4>
                        <p class="text-orange-600 whitespace-pre-wrap">{{ $pending['description'] }}</p>
                    </div>
                @endif
                
                @if(isset($pending['price']))
                    <div>
                        <h4 class="font-semibold text-gray-700 mb-2">{{ __('admin.ads.show_page.current_price') }}:</h4>
                        <p class="text-gray-600 mb-2">{{ format_price($ad->price, 0, $ad->currency) }}</p>
                        <h4 class="font-semibold text-orange-700 mb-2">{{ __('admin.ads.show_page.pending_price') }}:</h4>
                        <p class="text-orange-600">{{ format_price($pending['price'], 0, $pending['currency'] ?? $ad->currency) }}</p>
                    </div>
                @endif
                
                @if(isset($pending['images']))
                    <div>
                        <h4 class="font-semibold text-gray-700 mb-2">{{ __('admin.ads.show_page.current_images') }}:</h4>
                        <div class="grid grid-cols-3 gap-2 mb-4">
                            @php
                                $currentImages = is_array($ad->images) ? $ad->images : (is_string($ad->images) ? json_decode($ad->images, true) : []);
                                $currentImages = $currentImages ?? [];
                            @endphp
                            @foreach($currentImages as $image)
                                @php
                                    $imagePath = is_string($image) ? $image : (is_array($image) ? ($image['path'] ?? $image) : '');
                                @endphp
                                @if($imagePath)
                                    <img src="{{ asset('storage/' . $imagePath) }}" alt="" class="w-full h-20 object-cover rounded">
                                @endif
                            @endforeach
                        </div>
                        <h4 class="font-semibold text-orange-700 mb-2">{{ __('admin.ads.show_page.pending_images') }}:</h4>
                        <div class="grid grid-cols-3 gap-2">
                            @foreach($pending['images'] ?? [] as $image)
                                @php
                                    $imagePath = is_string($image) ? $image : (is_array($image) ? ($image['path'] ?? $image) : '');
                                @endphp
                                @if($imagePath)
                                    <img src="{{ asset('storage/' . $imagePath) }}" alt="" class="w-full h-20 object-cover rounded">
                                @endif
                            @endforeach
                        </div>
                    </div>
                @endif
                
                @if(isset($pending['custom_fields']) && !empty($pending['custom_fields']))
                    <div>
                        <h4 class="font-semibold text-gray-700 mb-3">{{ __('admin.ads.show_page.custom_fields') }}:</h4>
                        @php
                            $categoryFields = $ad->category->custom_fields ?? [];
                            $currentCustomFields = $ad->custom_fields ?? [];
                            $pendingCustomFields = $pending['custom_fields'] ?? [];
                        @endphp
                        @if($categoryFields && count($categoryFields) > 0)
                            <div class="space-y-3">
                                @foreach($categoryFields as $field)
                                    @php
                                        $fieldId = $field['id'];
                                        $fieldLabel = $field['label'][app()->getLocale()] ?? $field['label']['ar'] ?? $fieldId;
                                        $hasChange = isset($pendingCustomFields[$fieldId]) && 
                                                    isset($currentCustomFields[$fieldId]) && 
                                                    $pendingCustomFields[$fieldId] != $currentCustomFields[$fieldId];
                                        $isNew = isset($pendingCustomFields[$fieldId]) && !isset($currentCustomFields[$fieldId]);
                                        $isRemoved = !isset($pendingCustomFields[$fieldId]) && isset($currentCustomFields[$fieldId]);
                                    @endphp
                                    @if($hasChange || $isNew || $isRemoved)
                                        <div class="bg-white rounded-lg p-4 border border-orange-200">
                                            <h5 class="font-semibold text-gray-700 mb-2">{{ $fieldLabel }}:</h5>
                                            @if($isRemoved)
                                                <div>
                                                    <p class="text-gray-500 text-sm mb-1">{{ __('admin.ads.show_page.current_value') }}:</p>
                                                    <p class="text-gray-600 mb-2">
                                                        @if($field['type'] === 'select')
                                                            @php
                                                                $option = collect($field['options'])->firstWhere('id', $currentCustomFields[$fieldId]);
                                                            @endphp
                                                            {{ $option ? ($option[app()->getLocale()] ?? $option['ar'] ?? $currentCustomFields[$fieldId]) : $currentCustomFields[$fieldId] }}
                                                        @else
                                                            {{ $currentCustomFields[$fieldId] }}
                                                        @endif
                                                    </p>
                                                    <p class="text-orange-600 font-semibold">{{ __('admin.ads.show_page.pending_value') }}: <span class="text-gray-400">{{ __('admin.ads.show_page.removed') }}</span></p>
                                                </div>
                                            @else
                                                <div>
                                                    @if(isset($currentCustomFields[$fieldId]))
                                                        <p class="text-gray-500 text-sm mb-1">{{ __('admin.ads.show_page.current_value') }}:</p>
                                                        <p class="text-gray-600 mb-2">
                                                            @if($field['type'] === 'select')
                                                                @php
                                                                    $option = collect($field['options'])->firstWhere('id', $currentCustomFields[$fieldId]);
                                                                @endphp
                                                                {{ $option ? ($option[app()->getLocale()] ?? $option['ar'] ?? $currentCustomFields[$fieldId]) : $currentCustomFields[$fieldId] }}
                                                            @elseif($field['type'] === 'location' && is_array($currentCustomFields[$fieldId]))
                                                                {{ $currentCustomFields[$fieldId]['address'] ?? __('admin.ads.show_page.location') }}
                                                            @else
                                                                {{ $currentCustomFields[$fieldId] }}
                                                            @endif
                                                        </p>
                                                    @endif
                                                    <p class="text-orange-600 font-semibold">{{ __('admin.ads.show_page.pending_value') }}:</p>
                                                    <p class="text-orange-600">
                                                        @if($field['type'] === 'select')
                                                            @php
                                                                $option = collect($field['options'])->firstWhere('id', $pendingCustomFields[$fieldId]);
                                                            @endphp
                                                            {{ $option ? ($option[app()->getLocale()] ?? $option['ar'] ?? $pendingCustomFields[$fieldId]) : $pendingCustomFields[$fieldId] }}
                                                        @elseif($field['type'] === 'location' && is_array($pendingCustomFields[$fieldId]))
                                                            {{ $pendingCustomFields[$fieldId]['address'] ?? __('admin.ads.show_page.location') }}
                                                        @else
                                                            {{ $pendingCustomFields[$fieldId] }}
                                                        @endif
                                                    </p>
                                                </div>
                                            @endif
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                        @endif
                    </div>
                @endif
            </div>
        </div>
    @endif

    <!-- Ad Details -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Info -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Description -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <h3 class="text-xl font-bold text-primary mb-4">{{ __('admin.ads.show_page.description') }}</h3>
                <p class="text-gray-700 whitespace-pre-wrap">{{ $ad->description }}</p>
            </div>

            <!-- Images -->
            @php
                $images = is_array($ad->images) ? $ad->images : (is_string($ad->images) ? json_decode($ad->images, true) : []);
                $images = $images ?? [];
            @endphp
            @if(!empty($images) && is_array($images) && count($images) > 0)
            <div class="bg-white rounded-xl shadow-md p-6">
                <h3 class="text-xl font-bold text-primary mb-4">{{ __('admin.ads.show_page.images') }} ({{ count($images) }})</h3>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                    @foreach($images as $image)
                        @php
                            $imagePath = is_string($image) ? $image : (is_array($image) ? ($image['path'] ?? $image) : '');
                        @endphp
                        @if($imagePath)
                            <img src="{{ asset('storage/' . $imagePath) }}" 
                                 alt="{{ __('admin.ads.show_page.images') }}" 
                                 class="w-full h-40 object-cover rounded-lg"
                                 onerror="this.style.display='none';">
                        @endif
                    @endforeach
                </div>
            </div>
            @endif
        </div>

        <!-- Sidebar -->
        <div class="space-y-6">
            <!-- User Info -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <h3 class="text-lg font-bold text-primary mb-4">{{ __('admin.ads.show_page.user') }}</h3>
                <div class="flex items-center gap-3 mb-4">
                    <img src="{{ $ad->user->avatar ? asset('storage/' . $ad->user->avatar) : 'https://ui-avatars.com/api/?name=' . urlencode($ad->user->name) }}"
                         alt="{{ $ad->user->name }}"
                         class="w-12 h-12 rounded-full border-2 border-secondary">
                    <div>
                        <p class="font-semibold text-gray-800">{{ $ad->user->name }}</p>
                        <p class="text-xs text-gray-500">{{ $ad->user->email }}</p>
                    </div>
                </div>
                <a href="{{ route('admin.users.show', $ad->user->id) }}"
                   class="block text-center bg-blue-50 text-blue-600 hover:bg-blue-100 py-2 rounded-lg transition">
                    <i class="fas fa-user"></i> {{ __('admin.ads.show_page.view_profile') }}
                </a>
            </div>

            <!-- Category Info -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <h3 class="text-lg font-bold text-primary mb-4">{{ __('admin.ads.show_page.category') }}</h3>
                <div class="space-y-2">
                    <p class="text-sm">
                        <span class="font-semibold">{{ __('admin.ads.show_page.main_category') }}:</span>
                        <span class="text-gray-700">{{ $ad->category->name_ar }}</span>
                    </p>
                    @if($ad->subcategory)
                        <p class="text-sm">
                            <span class="font-semibold">{{ __('admin.ads.show_page.subcategory') }}:</span>
                            <span class="text-gray-700">{{ $ad->subcategory->name_ar }}</span>
                        </p>
                    @endif
                </div>
            </div>

            <!-- Custom Fields -->
            @if($ad->custom_fields && $ad->category->custom_fields)
                @php
                    $categoryFields = $ad->category->custom_fields ?? [];
                    $adCustomFields = $ad->custom_fields;
                @endphp
                @if($categoryFields && $adCustomFields)
                    <div class="bg-white rounded-xl shadow-md p-6">
                        <h3 class="text-lg font-bold text-primary mb-4">{{ __('admin.ads.show_page.custom_fields') }}</h3>
                        <div class="space-y-2">
                            @foreach($categoryFields as $field)
                                @if(isset($adCustomFields[$field['id']]))
                                    <div class="border-b border-gray-100 pb-2">
                                        <span class="text-sm font-semibold text-gray-600">{{ $field['label']['ar'] ?? $field['id'] }}:</span>
                                        <span class="text-sm text-gray-800 mr-2">
                                            {{ $adCustomFields[$field['id']] }}
                                        </span>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                @endif
            @endif

            <!-- Location Info -->
            @if($ad->location_city || $ad->location_district)
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h3 class="text-lg font-bold text-primary mb-4">{{ __('admin.ads.show_page.location') }}</h3>
                    <div class="space-y-2">
                        @if($ad->location_city)
                            <p class="text-sm">
                                <span class="font-semibold">{{ __('admin.ads.show_page.city') }}:</span>
                                <span class="text-gray-700">{{ $ad->location_city }}</span>
                            </p>
                        @endif
                        @if($ad->location_district)
                            <p class="text-sm">
                                <span class="font-semibold">{{ __('admin.ads.show_page.district') }}:</span>
                                <span class="text-gray-700">{{ $ad->location_district }}</span>
                            </p>
                        @endif
                        @if($ad->location_address)
                            <p class="text-sm">
                                <span class="font-semibold">{{ __('admin.ads.show_page.address') }}:</span>
                                <span class="text-gray-700">{{ $ad->location_address }}</span>
                            </p>
                        @endif
                    </div>
                </div>
            @endif

            <!-- Stats -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <h3 class="text-lg font-bold text-primary mb-4">{{ __('admin.ads.show_page.stats') }}</h3>
                <div class="space-y-3">
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">{{ __('admin.ads.show_page.views') }}</span>
                        <span class="font-bold text-primary">{{ $ad->views_count }}</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">{{ __('admin.ads.show_page.published_at') }}</span>
                        <span class="text-sm">{{ $ad->created_at->format('Y-m-d') }}</span>
                    </div>
                    @if($ad->published_at)
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-600">{{ __('admin.ads.show_page.activated_at') }}</span>
                        <span class="text-sm">{{ $ad->published_at->format('Y-m-d') }}</span>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

