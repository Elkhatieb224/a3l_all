@extends('admin.layouts.app')

@section('title', __('admin.reports.show.title'))
@section('page-title', __('admin.reports.show.title'))

@section('content')
<div class="max-w-4xl mx-auto space-y-6">
    <!-- Report Info -->
    <div class="bg-white rounded-xl shadow-md p-6">
        <div class="flex items-center justify-between mb-6">
            <div>
                <h2 class="text-2xl font-bold text-primary mb-2">{{ __('admin.reports.show.report_number', ['id' => $report->id]) }}</h2>
                <div class="flex items-center gap-3">
                    <span class="px-4 py-2 rounded-full text-sm font-semibold
                        {{ $report->status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                           ($report->status === 'reviewed' ? 'bg-blue-100 text-blue-700' :
                           ($report->status === 'resolved' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700')) }}">
                        {{ $report->status }}
                    </span>

                    <span class="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-semibold">
                        {{ $report->type }}
                    </span>
                </div>
            </div>
        </div>

        <!-- Report Details -->
        <div class="space-y-4">
            <div>
                <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.show.reason_label') }}</p>
                <p class="text-gray-800 bg-gray-50 p-4 rounded-lg">{{ $report->reason }}</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.show.reported_by_label') }}</p>
                    <div class="flex items-center gap-2">
                        <img src="{{ $report->user->avatar ? asset('storage/' . $report->user->avatar) : 'https://ui-avatars.com/api/?name=' . urlencode($report->user->name) }}"
                             class="w-8 h-8 rounded-full">
                        <a href="{{ route('admin.users.show', $report->user->id) }}" 
                           class="font-semibold text-primary hover:underline">
                            {{ $report->user->name }}
                        </a>
                    </div>
                </div>

                @if($report->ad)
                <div>
                    <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.show.reported_ad_label') }}</p>
                    <div class="space-y-2">
                        <p class="font-semibold">{{ Str::limit($report->ad->title, 50) }}</p>
                        <div class="flex items-center gap-2">
                            <span class="text-xs text-gray-500">UID:</span>
                            <span class="text-xs font-mono bg-gray-100 px-2 py-1 rounded">{{ $report->ad->uid }}</span>
                        </div>
                        <a href="{{ route('ads.show', $report->ad->uid) }}" 
                           target="_blank"
                           class="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition text-sm">
                            <i class="fas fa-external-link-alt"></i>
                            {{ __('admin.reports.view_ad') }}
                        </a>
                    </div>
                </div>
                @endif

                @if($report->ad && $report->ad->user)
                <div>
                    <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.show.ad_owner_label') }}</p>
                    <div class="flex items-center gap-2">
                        <img src="{{ $report->ad->user->avatar ? asset('storage/' . $report->ad->user->avatar) : 'https://ui-avatars.com/api/?name=' . urlencode($report->ad->user->name) }}"
                             class="w-8 h-8 rounded-full">
                        <a href="{{ route('admin.users.show', $report->ad->user->id) }}" 
                           class="font-semibold text-primary hover:underline">
                            {{ $report->ad->user->name }}
                        </a>
                    </div>
                </div>
                @endif

                @if($report->reportedUser)
                <div>
                    <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.show.reported_user_label') }}</p>
                    <div class="flex items-center gap-2">
                        <img src="{{ $report->reportedUser->avatar ? asset('storage/' . $report->reportedUser->avatar) : 'https://ui-avatars.com/api/?name=' . urlencode($report->reportedUser->name) }}"
                             class="w-8 h-8 rounded-full">
                        <a href="{{ route('admin.users.show', $report->reportedUser->id) }}" 
                           class="font-semibold text-primary hover:underline">
                            {{ $report->reportedUser->name }}
                        </a>
                    </div>
                </div>
                @endif

                @if($report->conversation)
                <div>
                    <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.show.conversation_label') }}</p>
                    <div class="space-y-2">
                        <p class="font-semibold">{{ $report->conversation->ad->title }}</p>
                    </div>
                </div>
                @endif

                @if($report->conversation)
                <div>
                    <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.show.sender_label') }}</p>
                    <div class="flex items-center gap-2">
                        <img src="{{ $report->conversation->sender->avatar ? asset('storage/' . $report->conversation->sender->avatar) : 'https://ui-avatars.com/api/?name=' . urlencode($report->conversation->sender->name) }}"
                             class="w-8 h-8 rounded-full">
                        <a href="{{ route('admin.users.show', $report->conversation->sender->id) }}" 
                           class="font-semibold text-primary hover:underline">
                            {{ $report->conversation->sender->name }}
                        </a>
                    </div>
                </div>
                @endif

                @if($report->conversation)
                <div>
                    <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.show.receiver_label') }}</p>
                    <div class="flex items-center gap-2">
                        <img src="{{ $report->conversation->receiver->avatar ? asset('storage/' . $report->conversation->receiver->avatar) : 'https://ui-avatars.com/api/?name=' . urlencode($report->conversation->receiver->name) }}"
                             class="w-8 h-8 rounded-full">
                        <a href="{{ route('admin.users.show', $report->conversation->receiver->id) }}" 
                           class="font-semibold text-primary hover:underline">
                            {{ $report->conversation->receiver->name }}
                        </a>
                    </div>
                </div>
                @endif

                @if($report->conversation && $report->conversation_messages && count($report->conversation_messages) > 0)
                <div class="col-span-1 md:col-span-2">
                    <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.last_messages') }}:</p>
                    <div class="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-200 max-h-64 overflow-y-auto">
                        <div class="space-y-2">
                            @foreach($report->conversation_messages as $msg)
                                <div class="text-xs p-2 bg-white rounded border border-gray-200">
                                    <div class="flex items-center justify-between mb-1">
                                        <span class="font-semibold text-gray-800">{{ $msg['sender_name'] ?? 'Unknown' }}</span>
                                        <span class="text-gray-500">{{ \Carbon\Carbon::parse($msg['created_at'])->format('H:i') }}</span>
                                    </div>
                                    <p class="text-gray-700 whitespace-pre-wrap">{{ $msg['message'] ?? '' }}</p>
                                    @if(isset($msg['attachments']) && count($msg['attachments']) > 0)
                                        <div class="mt-1 text-xs text-blue-600">
                                            <i class="fas fa-paperclip"></i> {{ count($msg['attachments']) }} {{ __('admin.reports.attachments') }}
                                        </div>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                @endif
            </div>

            @if($report->admin_notes)
            <div>
                <p class="text-sm text-gray-600 mb-2">{{ __('admin.reports.show.admin_notes_label') }}</p>
                <p class="text-gray-800 bg-blue-50 p-4 rounded-lg">{{ $report->admin_notes }}</p>
            </div>
            @endif

            <!-- Block User Actions (Admin only) -->
            @if(auth('admin')->user()->isAdmin())
            @if($report->reportedUser || ($report->conversation && $report->conversation->sender_id !== $report->user_id && $report->conversation->receiver_id !== $report->user_id))
                <div class="mt-6 pt-6 border-t border-gray-200">
                    <h3 class="text-lg font-bold text-primary mb-4">{{ __('admin.reports.block_user') }}</h3>
                    @php
                        $userToBlock = $report->reportedUser ?? ($report->conversation->sender_id === $report->user_id ? $report->conversation->receiver : $report->conversation->sender);
                    @endphp
                    @if($userToBlock)
                        <div class="flex items-center gap-4">
                            <div class="flex items-center gap-2">
                                <img src="{{ $userToBlock->avatar ? asset('storage/' . $userToBlock->avatar) : 'https://ui-avatars.com/api/?name=' . urlencode($userToBlock->name) }}"
                                     class="w-10 h-10 rounded-full">
                                <div>
                                    <p class="font-semibold">{{ $userToBlock->name }}</p>
                                    <p class="text-sm text-gray-600">{{ $userToBlock->email }}</p>
                                </div>
                            </div>
                            @if(!$report->user->hasBlocked($userToBlock->id))
                                <form action="{{ route('admin.users.block', $userToBlock->id) }}" method="POST" class="ml-auto">
                                    @csrf
                                    <input type="hidden" name="report_id" value="{{ $report->id }}">
                                    <button type="submit" 
                                            onclick="return confirm('{{ __('admin.reports.confirm_block') }}')"
                                            class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition">
                                        <i class="fas fa-ban ml-2"></i>
                                        {{ __('admin.reports.block_user') }}
                                    </button>
                                </form>
                            @else
                                <span class="px-4 py-2 bg-gray-200 text-gray-600 rounded-lg">
                                    <i class="fas fa-ban ml-2"></i>
                                    {{ __('admin.reports.already_blocked') }}
                                </span>
                            @endif
                        </div>
                    @endif
                </div>
            @endif
            @endif
        </div>
    </div>

    <!-- Update Form (Admin only) -->
    @if(auth('admin')->user()->isAdmin())
    @if($report->status === 'pending')
    <form action="{{ route('admin.reports.update', $report->id) }}" method="POST" class="bg-white rounded-xl shadow-md p-6">
        @csrf
        @method('PUT')

        <h3 class="text-xl font-bold text-primary mb-6">{{ __('admin.reports.show.update_status_title') }}</h3>

        <div class="space-y-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    {{ __('admin.reports.show.status_required') }}
                </label>
                <select name="status"
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary">
                    <option value="reviewed">{{ __('admin.reports.show.status_options.reviewed') }}</option>
                    <option value="resolved">{{ __('admin.reports.show.status_options.resolved') }}</option>
                    <option value="rejected">{{ __('admin.reports.show.status_options.rejected') }}</option>
                </select>
            </div>

            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    {{ __('admin.reports.show.admin_notes_label_form') }}
                </label>
                <textarea name="admin_notes"
                          rows="4"
                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary"></textarea>
            </div>

            <button type="submit" class="btn-primary px-6 py-3 rounded-lg font-bold">
                <i class="fas fa-save ml-2"></i>
                {{ __('admin.reports.show.save_update_button') }}
            </button>
        </div>
    </form>
    @endif
    @endif
</div>
@endsection

