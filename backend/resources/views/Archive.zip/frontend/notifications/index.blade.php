@extends('frontend.layouts.app')

@section('title', __('frontend.notifications.title'))

@section('content')
<div class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <div class="bg-white rounded-lg shadow-md p-4 sm:p-6">
            <div class="flex items-center justify-between mb-6">
                <h1 class="text-xl sm:text-2xl font-bold text-gray-800">
                    {{ __('frontend.notifications.all_notifications') }}
                </h1>
                @if($notifications->whereNull('read_at')->count() > 0)
                    <form action="{{ route('profile.notifications.read-all') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit" class="text-sm text-primary hover:underline">
                            {{ __('frontend.notifications.mark_all_read') }}
                        </button>
                    </form>
                @endif
            </div>

            @if($notifications->count() > 0)
                <div class="space-y-3">
                    @foreach($notifications as $notification)
                        @php
                            $notificationData = $notification->data ?? [];
                            $adUrl = $notificationData['ad_url'] ?? null;
                            $adUid = $notificationData['ad_uid'] ?? null;
                            $isClickable = ($notificationData['type'] ?? null) === 'ad_updated' && $adUrl;
                        @endphp
                        
                        @if($isClickable)
                            <a href="{{ $adUrl }}" 
                               onclick="event.preventDefault(); markNotificationAsRead('{{ $notification->id }}'); window.location.href='{{ $adUrl }}';"
                               class="block border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition {{ $notification->read_at ? '' : 'bg-blue-50' }} cursor-pointer">
                        @else
                            <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition {{ $notification->read_at ? '' : 'bg-blue-50' }}">
                        @endif
                            <div class="flex items-start gap-3">
                                <div class="flex-shrink-0 mt-1">
                                    <i class="fas fa-circle text-xs {{ $notification->read_at ? 'text-gray-300' : 'text-blue-500' }}"></i>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-start justify-between gap-2">
                                        <div class="flex-1">
                                            <p class="text-sm font-medium text-gray-800">
                                                {{ $notificationData['title'] ?? __('frontend.notifications.notification') }}
                                            </p>
                                            <p class="text-sm text-gray-600 mt-1">
                                                {{ $notificationData['message'] ?? '' }}
                                            </p>
                                            <div class="flex items-center gap-4 mt-2 text-xs text-gray-500">
                                                <span>
                                                    <i class="fas fa-clock ml-1"></i>
                                                    {{ $notification->created_at->format('Y-m-d H:i') }}
                                                </span>
                                                <span>
                                                    <i class="fas fa-history ml-1"></i>
                                                    {{ $notification->created_at->diffForHumans() }}
                                                </span>
                                                @if(!$notification->read_at)
                                                    <span class="text-blue-600">
                                                        <i class="fas fa-circle ml-1"></i>
                                                        {{ __('frontend.notifications.unread') }}
                                                    </span>
                                                @endif
                                            </div>
                                        </div>
                                        @if(!$notification->read_at && !$isClickable)
                                            <form action="{{ route('profile.notifications.read', $notification->id) }}" method="POST" class="inline">
                                                @csrf
                                                <button type="submit" class="text-xs text-primary hover:underline">
                                                    {{ __('frontend.notifications.mark_as_read') }}
                                                </button>
                                            </form>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        @if($isClickable)
                            </a>
                        @else
                            </div>
                        @endif
                    @endforeach
                </div>

                <!-- Pagination -->
                <div class="mt-6">
                    {{ $notifications->links() }}
                </div>
            @else
                <div class="text-center py-12">
                    <i class="fas fa-bell-slash text-gray-300 text-6xl mb-4"></i>
                    <p class="text-gray-500">{{ __('frontend.notifications.no_notifications') }}</p>
                </div>
            @endif
        </div>
    </div>
</div>

@push('scripts')
<script>
    function markNotificationAsRead(notificationId) {
        fetch(`/profile/notifications/${notificationId}/read`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        });
    }
</script>
@endpush
@endsection

