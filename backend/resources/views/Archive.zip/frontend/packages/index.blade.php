@extends('frontend.layouts.app')

@section('title', __('frontend.packages.title'))

@section('content')
<div class="bg-gray-50 min-h-screen py-8">
    <div class="container mx-auto px-2 sm:px-4">
        <!-- Header -->
        <div class="text-center mb-8">
            <h1 class="text-3xl sm:text-4xl font-bold text-gray-800 mb-4">{{ __('frontend.packages.title') }}</h1>
            <p class="text-gray-600 text-lg">{{ __('frontend.packages.subtitle') }}</p>
        </div>

        @if(session('error'))
            <div class="max-w-4xl mx-auto mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                <i class="fas fa-exclamation-circle ml-1"></i> {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div class="max-w-4xl mx-auto mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-sm text-green-600">
                <i class="fas fa-check-circle ml-1"></i> {{ session('success') }}
            </div>
        @endif

        @auth
            <!-- Free Ads Info -->
            <div class="max-w-4xl mx-auto mb-8 bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div>
                        <h3 class="text-lg font-bold text-gray-800 mb-2">{{ __('frontend.packages.free_ads_info') }}</h3>
                        <p class="text-gray-600">
                            {{ __('frontend.packages.remaining_free_ads') }}: 
                            <span class="font-bold text-primary text-xl">{{ $remainingFreeAds }}</span> / {{ $freeAdsLimit }}
                        </p>
                    </div>
                    @if($remainingFreeAds > 0)
                        <a href="{{ route('ads.create') }}" class="btn-primary px-6 py-3 rounded-lg">
                            <i class="fas fa-plus ml-2"></i>
                            {{ __('frontend.ads.create_ad') }}
                        </a>
                    @endif
                </div>
            </div>
        @endauth

        <!-- Packages Grid -->
        @if($packages->count() > 0)
            <div class="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($packages as $package)
                    <div class="bg-white rounded-xl shadow-lg overflow-hidden border-t-4 border-secondary transform hover:scale-105 transition duration-300">
                        <div class="p-6">
                            <!-- Header -->
                            <div class="text-center mb-6">
                                <h3 class="text-2xl font-bold text-primary mb-2">{{ $package->getName(app()->getLocale()) }}</h3>
                                @if($package->description_ar || $package->description_en || $package->description_tr)
                                    <p class="text-sm text-gray-600">{{ $package->getDescription(app()->getLocale()) }}</p>
                                @endif
                            </div>

                            <!-- Price -->
                            <div class="text-center mb-6 py-4 bg-gradient-to-r from-primary to-blue-900 rounded-lg">
                                <div class="text-4xl font-bold text-secondary">
                                    {{ number_format($package->price, 0) }}
                                </div>
                                <div class="text-white text-sm mt-1">
                                    {{ format_price($package->price, 0, $package->currency) }}
                                    <span class="text-xs">/ {{ $package->duration_days }} {{ __('frontend.packages.days') }}</span>
                                </div>
                            </div>

                            <!-- Features -->
                            <div class="space-y-3 mb-6">
                                <div class="flex items-center gap-2 text-sm">
                                    <i class="fas fa-check-circle text-green-500"></i>
                                    <span>{{ $package->ads_limit }} {{ __('frontend.ads.total_ads') }}</span>
                                </div>

                                @if($package->featured_ads)
                                    <div class="flex items-center gap-2 text-sm">
                                        <i class="fas fa-star text-secondary"></i>
                                        <span>{{ __('frontend.ads.featured') }}</span>
                                    </div>
                                @endif

                                @if($package->urgent_ads)
                                    <div class="flex items-center gap-2 text-sm">
                                        <i class="fas fa-bolt text-red-500"></i>
                                        <span>{{ __('frontend.ads.urgent') }}</span>
                                    </div>
                                @endif

                                @if($package->priority_support)
                                    <div class="flex items-center gap-2 text-sm">
                                        <i class="fas fa-headset text-blue-500"></i>
                                        <span>{{ __('frontend.packages.priority_support') }}</span>
                                    </div>
                                @endif

                                @if($package->homepage_display)
                                    <div class="flex items-center gap-2 text-sm">
                                        <i class="fas fa-home text-purple-500"></i>
                                        <span>{{ __('frontend.packages.homepage_display') }}</span>
                                    </div>
                                @endif
                            </div>

                            <!-- Subscribe Button -->
                            @auth
                                <form action="{{ route('packages.subscribe', $package->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn-primary w-full py-3 rounded-lg font-bold">
                                        <i class="fas fa-shopping-cart ml-2"></i>
                                        {{ __('frontend.packages.subscribe') }}
                                    </button>
                                </form>
                            @else
                                <a href="{{ route('login') }}" 
                                   class="btn-primary w-full block text-center py-3 rounded-lg font-bold">
                                    <i class="fas fa-sign-in-alt ml-2"></i>
                                    {{ __('frontend.packages.login_to_subscribe') }}
                                </a>
                            @endauth
                        </div>
                    </div>
                @endforeach
            </div>
        @else
            <div class="max-w-4xl mx-auto bg-white rounded-xl shadow-md p-12 text-center">
                <i class="fas fa-box text-6xl text-gray-300 mb-4"></i>
                <p class="text-gray-500 text-lg">{{ __('frontend.packages.no_packages') }}</p>
            </div>
        @endif
    </div>
</div>
@endsection

