@extends('frontend.layouts.app')

@section('title', __('frontend.ads.ad_details'))

@section('content')
<div class="bg-gray-50 min-h-screen py-8">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto">
            <!-- Header -->
            <div class="text-center mb-8">
                <h1 class="text-3xl font-bold text-gray-800 mb-2">{{ __('frontend.ads.ad_details') }}</h1>
                <p class="text-gray-600">{{ __('frontend.ads.fill_ad_details') }}</p>
            </div>

            <!-- Selected Category Path -->
            <div class="bg-white rounded-lg shadow-md p-4 mb-6">
                <div class="flex items-center gap-2 flex-wrap text-sm">
                    @if(!empty($adData['subcategories']))
                        @foreach(array_reverse($adData['subcategories']) as $index => $sub)
                            <span class="text-gray-700">{{ $sub['name'] }}</span>
                            @if($index < count($adData['subcategories']) - 1)
                                <span class="text-gray-400"> < </span>
                            @endif
                        @endforeach
                        <span class="text-gray-400"> < </span>
                    @endif
                    <span class="text-primary font-semibold">{{ $category->getName(app()->getLocale()) }}</span>
                </div>
            </div>

            <!-- Ad Details Form -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <form action="{{ route('ads.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                    @csrf

                    <!-- Title -->
                    <div>
                        <label for="title" class="block text-sm font-semibold text-gray-700 mb-2">
                            {{ __('frontend.ads.title') }} <span class="text-red-500">*</span>
                        </label>
                        <input type="text" 
                               name="title" 
                               id="title" 
                               value="{{ old('title') }}"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                               placeholder="{{ __('frontend.ads.title_placeholder') }}"
                               required>
                        @error('title')
                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Description -->
                    <div>
                        <label for="description" class="block text-sm font-semibold text-gray-700 mb-2">
                            {{ __('frontend.ads.description') }} <span class="text-red-500">*</span>
                        </label>
                        <textarea name="description" 
                                  id="description" 
                                  rows="8" 
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                  placeholder="{{ __('frontend.ads.description_placeholder') }}"
                                  required>{{ old('description') }}</textarea>
                        @error('description')
                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Price -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="price" class="block text-sm font-semibold text-gray-700 mb-2">
                                {{ __('frontend.ads.price') }} <span class="text-gray-500">({{ __('frontend.optional') }})</span>
                            </label>
                            <input type="number" 
                                   name="price" 
                                   id="price" 
                                   value="{{ old('price') }}"
                                   step="0.01"
                                   min="0"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                   placeholder="{{ __('frontend.ads.price_placeholder') }}">
                            @error('price')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                        <div>
                            <label for="currency" class="block text-sm font-semibold text-gray-700 mb-2">
                                {{ __('frontend.ads.currency') }}
                            </label>
                            <select name="currency" 
                                    id="currency"
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                                <option value="SYP" {{ old('currency', \App\Models\Setting::get('default_currency', 'SYP')) === 'SYP' ? 'selected' : '' }}>🇸🇾 الليرة السورية (SYP)</option>
                                <option value="TRY" {{ old('currency') === 'TRY' ? 'selected' : '' }}>🇹🇷 الليرة التركية (TRY)</option>
                                <option value="USD" {{ old('currency') === 'USD' ? 'selected' : '' }}>🇺🇸 الدولار الأمريكي (USD)</option>
                                <option value="EUR" {{ old('currency') === 'EUR' ? 'selected' : '' }}>🇪🇺 اليورو (EUR)</option>
                            </select>
                            @error('currency')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                    <!-- Custom Fields -->
                    @if(!empty($customFields))
                    <div class="border-t pt-6">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">{{ __('frontend.ads.additional_details') }}</h3>
                        <div class="space-y-4">
                            @foreach($customFields as $field)
                                @php
                                    $fieldId = $field['id'] ?? 'field_' . $loop->index;
                                    $fieldType = $field['type'] ?? 'text';
                                    $fieldLabel = $field['label'][app()->getLocale()] ?? $field['label']['ar'] ?? $fieldId;
                                    $isRequired = $field['required'] ?? false;
                                    $fieldValue = old('custom_fields.' . $fieldId);
                                @endphp
                                
                                <div>
                                    <label for="custom_fields_{{ $fieldId }}" class="block text-sm font-semibold text-gray-700 mb-2">
                                        {{ $fieldLabel }}
                                        @if($isRequired)
                                            <span class="text-red-500">*</span>
                                        @endif
                                    </label>
                                    
                                    @if($fieldType === 'textarea')
                                        <textarea name="custom_fields[{{ $fieldId }}]" 
                                                  id="custom_fields_{{ $fieldId }}" 
                                                  rows="4"
                                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                                  @if($isRequired) required @endif>{{ $fieldValue }}</textarea>
                                    @elseif($fieldType === 'select' && isset($field['options']))
                                        <select name="custom_fields[{{ $fieldId }}]" 
                                                id="custom_fields_{{ $fieldId }}"
                                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                                @if($isRequired) required @endif>
                                            <option value="">{{ __('frontend.ads.select_option') }}</option>
                                            @foreach($field['options'] as $option)
                                                <option value="{{ $option[app()->getLocale()] ?? $option['ar'] ?? $option }}" 
                                                        {{ $fieldValue == ($option[app()->getLocale()] ?? $option['ar'] ?? $option) ? 'selected' : '' }}>
                                                    {{ $option[app()->getLocale()] ?? $option['ar'] ?? $option }}
                                                </option>
                                            @endforeach
                                        </select>
                                    @elseif($fieldType === 'number')
                                        <input type="number" 
                                               name="custom_fields[{{ $fieldId }}]" 
                                               id="custom_fields_{{ $fieldId }}"
                                               value="{{ $fieldValue }}"
                                               step="{{ $field['step'] ?? 1 }}"
                                               min="{{ $field['min'] ?? '' }}"
                                               max="{{ $field['max'] ?? '' }}"
                                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                               @if($isRequired) required @endif>
                                    @elseif($fieldType === 'checkbox')
                                        <div class="flex items-center gap-2">
                                            <input type="checkbox" 
                                                   name="custom_fields[{{ $fieldId }}]" 
                                                   id="custom_fields_{{ $fieldId }}"
                                                   value="1"
                                                   {{ $fieldValue ? 'checked' : '' }}
                                                   class="w-5 h-5 text-primary border-gray-300 rounded focus:ring-primary">
                                            <label for="custom_fields_{{ $fieldId }}" class="text-sm text-gray-600">
                                                {{ __('frontend.ads.yes') }}
                                            </label>
                                        </div>
                                    @elseif($fieldType === 'location')
                                        <div class="space-y-3">
                                            <div class="grid grid-cols-2 gap-3">
                                                <div>
                                                    <label class="block text-xs text-gray-600 mb-1">خط العرض (Latitude)</label>
                                                    <input type="number" 
                                                           name="custom_fields[{{ $fieldId }}][lat]" 
                                                           id="custom_fields_{{ $fieldId }}_lat"
                                                           value="{{ is_array($fieldValue) ? ($fieldValue['lat'] ?? '') : '' }}"
                                                           step="any"
                                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                                           placeholder="33.5138"
                                                           @if($isRequired) required @endif>
                                                </div>
                                                <div>
                                                    <label class="block text-xs text-gray-600 mb-1">خط الطول (Longitude)</label>
                                                    <input type="number" 
                                                           name="custom_fields[{{ $fieldId }}][lng]" 
                                                           id="custom_fields_{{ $fieldId }}_lng"
                                                           value="{{ is_array($fieldValue) ? ($fieldValue['lng'] ?? '') : '' }}"
                                                           step="any"
                                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                                           placeholder="36.2765"
                                                           @if($isRequired) required @endif>
                                                </div>
                                            </div>
                                            <div>
                                                <label class="block text-xs text-gray-600 mb-1">العنوان (اختياري)</label>
                                                <input type="text" 
                                                       name="custom_fields[{{ $fieldId }}][address]" 
                                                       id="custom_fields_{{ $fieldId }}_address"
                                                       value="{{ is_array($fieldValue) ? ($fieldValue['address'] ?? '') : '' }}"
                                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                                       placeholder="{{ __('frontend.ads.location_address_placeholder') }}">
                                            </div>
                                            <div id="map_{{ $fieldId }}" class="w-full h-64 border border-gray-300 rounded-lg"></div>
                                            <button type="button" onclick="initMap('{{ $fieldId }}')" class="btn-primary px-4 py-2 rounded-lg text-sm">
                                                <i class="fas fa-map-marker-alt ml-2"></i>
                                                {{ __('frontend.ads.select_location') }}
                                            </button>
                                        </div>
                                    @else
                                        <input type="text" 
                                               name="custom_fields[{{ $fieldId }}]" 
                                               id="custom_fields_{{ $fieldId }}"
                                               value="{{ $fieldValue }}"
                                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                               @if($isRequired) required @endif>
                                    @endif
                                    
                                    @error('custom_fields.' . $fieldId)
                                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                    @enderror
                                </div>
                            @endforeach
                        </div>
                    </div>
                    @endif

                    <!-- Location Section -->
                    <div class="border-t pt-6">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">{{ __('frontend.ads.location_section') }}</h3>
                        <div class="space-y-4">
                            <!-- Country -->
                            <div>
                                <label for="location_country" class="block text-sm font-semibold text-gray-700 mb-2">
                                    {{ __('frontend.ads.location_country') }} <span class="text-red-500">*</span>
                                </label>
                                <select name="location_country" 
                                        id="location_country"
                                        required
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                                    <option value="">{{ __('frontend.ads.select_country') }}</option>
                                    <option value="SY" {{ old('location_country', 'SY') === 'SY' ? 'selected' : '' }}>🇸🇾 سوريا</option>
                                    <option value="TR" {{ old('location_country') === 'TR' ? 'selected' : '' }}>🇹🇷 تركيا</option>
                                </select>
                                @error('location_country')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <!-- State/Province -->
                            <div>
                                <label for="location_city" class="block text-sm font-semibold text-gray-700 mb-2">
                                    {{ __('frontend.ads.location_state') }} <span class="text-red-500">*</span>
                                </label>
                                <input type="text" 
                                       name="location_city" 
                                       id="location_city" 
                                       value="{{ old('location_city') }}"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                       placeholder="{{ __('frontend.ads.location_state_placeholder') }}"
                                       required>
                                @error('location_city')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <!-- District -->
                            <div>
                                <label for="location_district" class="block text-sm font-semibold text-gray-700 mb-2">
                                    {{ __('frontend.ads.location_district') }} <span class="text-red-500">*</span>
                                </label>
                                <input type="text" 
                                       name="location_district" 
                                       id="location_district" 
                                       value="{{ old('location_district') }}"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                       placeholder="{{ __('frontend.ads.location_district_placeholder') }}"
                                       required>
                                @error('location_district')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <!-- Street Name -->
                            <div>
                                <label for="location_address" class="block text-sm font-semibold text-gray-700 mb-2">
                                    {{ __('frontend.ads.location_street') }} <span class="text-red-500">*</span>
                                </label>
                                <input type="text" 
                                       name="location_address" 
                                       id="location_address" 
                                       value="{{ old('location_address') }}"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                       placeholder="{{ __('frontend.ads.location_street_placeholder') }}"
                                       required>
                                @error('location_address')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <!-- Images -->
                    <div>
                        <label for="images" class="block text-sm font-semibold text-gray-700 mb-2">
                            {{ __('frontend.ads.images') }} <span class="text-gray-500">({{ __('frontend.optional') }})</span>
                        </label>
                        <input type="file" 
                               name="images[]" 
                               id="images" 
                               multiple 
                               accept="image/*"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                        <p class="text-xs text-gray-500 mt-2">
                            {{ __('frontend.ads.images_hint') }}
                        </p>
                        @error('images.*')
                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Preview Selected Images -->
                    <div id="images-preview" class="hidden">
                        <h3 class="text-sm font-semibold text-gray-700 mb-3">{{ __('frontend.ads.selected_images') }}:</h3>
                        <div id="images-list" class="grid grid-cols-2 md:grid-cols-4 gap-4"></div>
                    </div>

                    <!-- Buttons -->
                    <div class="flex items-center justify-between gap-4 pt-4 border-t">
                        <a href="{{ route('ads.create.subcategory') }}" 
                           class="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-semibold">
                            <i class="fas fa-arrow-right ml-2"></i>
                            {{ __('frontend.back') }}
                        </a>
                        <button type="submit" class="btn-primary px-8 py-3 rounded-lg font-bold">
                            <i class="fas fa-check ml-2"></i>
                            {{ __('frontend.ads.submit_ad') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('images');
    const imagesPreview = document.getElementById('images-preview');
    const imagesList = document.getElementById('images-list');

    fileInput.addEventListener('change', function() {
        imagesList.innerHTML = '';
        
        if (this.files.length > 0) {
            imagesPreview.classList.remove('hidden');
            
            Array.from(this.files).forEach((file) => {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const imageItem = document.createElement('div');
                    imageItem.className = 'relative';
                    imageItem.innerHTML = `
                        <img src="${e.target.result}" 
                             alt="${file.name}" 
                             class="w-full h-32 object-cover rounded-lg">
                        <span class="absolute top-2 right-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
                            ${(file.size / 1024 / 1024).toFixed(2)} MB
                        </span>
                    `;
                    imagesList.appendChild(imageItem);
                };
                reader.readAsDataURL(file);
            });
        } else {
            imagesPreview.classList.add('hidden');
        }
    });
});
</script>

@push('scripts')
<script src="https://maps.googleapis.com/maps/api/js?key={{ config('services.google_maps.api_key', 'YOUR_API_KEY') }}&libraries=places&language={{ app()->getLocale() }}"></script>
<script>
const locationFields = @json(collect($customFields)->where('type', 'location')->pluck('id')->toArray());
const maps = {};

function initMap(fieldId) {
    if (maps[fieldId]) {
        return; // Map already initialized
    }
    
    const mapDiv = document.getElementById('map_' + fieldId);
    if (!mapDiv) return;
    
    const latInput = document.getElementById('custom_fields_' + fieldId + '_lat');
    const lngInput = document.getElementById('custom_fields_' + fieldId + '_lng');
    const addressInput = document.getElementById('custom_fields_' + fieldId + '_address');
    
    // Default location (Damascus, Syria)
    const defaultLat = parseFloat(latInput.value) || 33.5138;
    const defaultLng = parseFloat(lngInput.value) || 36.2765;
    
    const map = new google.maps.Map(mapDiv, {
        center: { lat: defaultLat, lng: defaultLng },
        zoom: 13,
    });
    
    const marker = new google.maps.Marker({
        map: map,
        draggable: true,
        position: { lat: defaultLat, lng: defaultLng },
    });
    
    // Initialize geocoder
    const geocoder = new google.maps.Geocoder();
    
    // Update inputs when marker is dragged
    marker.addListener('dragend', function() {
        const position = marker.getPosition();
        latInput.value = position.lat();
        lngInput.value = position.lng();
        
        // Reverse geocode to get address
        geocoder.geocode({ location: position }, function(results, status) {
            if (status === 'OK' && results[0]) {
                addressInput.value = results[0].formatted_address;
            }
        });
    });
    
    // Update marker when clicking on map
    map.addListener('click', function(event) {
        marker.setPosition(event.latLng);
        latInput.value = event.latLng.lat();
        lngInput.value = event.latLng.lng();
        
        geocoder.geocode({ location: event.latLng }, function(results, status) {
            if (status === 'OK' && results[0]) {
                addressInput.value = results[0].formatted_address;
            }
        });
    });
    
    // Search box
    if (addressInput) {
        const searchBox = new google.maps.places.SearchBox(addressInput);
        
        searchBox.addListener('places_changed', function() {
            const places = searchBox.getPlaces();
            if (places.length === 0) return;
            
            const place = places[0];
            if (!place.geometry) return;
            
            map.setCenter(place.geometry.location);
            map.setZoom(15);
            marker.setPosition(place.geometry.location);
            
            latInput.value = place.geometry.location.lat();
            lngInput.value = place.geometry.location.lng();
        });
    }
    
    maps[fieldId] = map;
}

// Initialize all location maps on page load
document.addEventListener('DOMContentLoaded', function() {
    locationFields.forEach(fieldId => {
        const mapDiv = document.getElementById('map_' + fieldId);
        if (mapDiv) {
            // Initialize map when button is clicked
            const initButton = mapDiv.nextElementSibling;
            if (initButton && initButton.tagName === 'BUTTON') {
                initButton.addEventListener('click', function() {
                    initMap(fieldId);
                });
            }
        }
    });
});
</script>
@endpush
@endsection

