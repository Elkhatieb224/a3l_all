@extends('frontend.layouts.app')

@section('title', $ad->title)

@section('content')
<div class="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
    <!-- Breadcrumb -->
    <nav class="mb-4 sm:mb-6 text-xs sm:text-sm overflow-x-auto">
        <ol class="flex items-center gap-1 sm:gap-2 text-gray-600 whitespace-nowrap">
            <li><a href="{{ route('home') }}" class="hover:text-primary">{{ __('frontend.nav.home') }}</a></li>
            <li><i class="fas fa-chevron-left text-xs"></i></li>
            <li><a href="{{ route('categories.show', $ad->category->slug) }}" class="hover:text-primary">
                {{ $ad->category->getName(app()->getLocale()) }}
            </a></li>
            @if($ad->subcategory)
                <li><i class="fas fa-chevron-left text-xs"></i></li>
                <li class="text-gray-800 font-semibold truncate">{{ $ad->subcategory->getName(app()->getLocale()) }}</li>
            @endif
        </ol>
    </nav>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        <!-- Main Content -->
        <main class="lg:col-span-2">
            <!-- Ad Header -->
            <div class="bg-gradient-to-br from-white to-gray-50 rounded-xl shadow-lg border border-gray-100 p-4 sm:p-6 mb-4 sm:mb-6">
                <div class="flex flex-col sm:flex-row items-start justify-between gap-3 sm:gap-0 mb-4">
                    <div class="flex-1 w-full">
                        <div class="flex flex-wrap items-center gap-2 mb-3">
                            @if($ad->is_featured)
                                <span class="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white px-3 py-1.5 rounded-full text-xs sm:text-sm font-bold shadow-md flex items-center gap-1.5">
                                    <i class="fas fa-star"></i> {{ __('frontend.ads.featured') }}
                                </span>
                            @endif
                            @if($ad->is_urgent)
                                <span class="bg-gradient-to-r from-red-500 to-red-600 text-white px-3 py-1.5 rounded-full text-xs sm:text-sm font-bold shadow-md flex items-center gap-1.5 animate-pulse">
                                    <i class="fas fa-exclamation-circle"></i> {{ __('frontend.ads.urgent') }}
                                </span>
                            @endif
                        </div>
                        <div class="flex items-start justify-between gap-4">
                            <div class="flex-1">
                                <h1 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 leading-tight">{{ $ad->title }}</h1>
                                @if($ad->price)
                                    <div class="flex items-baseline gap-2 mb-2">
                                        <span class="text-3xl sm:text-4xl font-bold text-primary">{{ format_price($ad->price, 0, $ad->currency) }}</span>
                                        @if($ad->currency !== 'USD')
                                            <span class="text-sm text-gray-500">({{ $ad->currency }})</span>
                                        @endif
                                    </div>
                                @endif
                            </div>
                            @auth
                                <button id="favorite-btn-mobile"
                                        data-uid="{{ $ad->uid }}"
                                        class="p-3 sm:p-4 rounded-xl transition-all duration-300 {{ $isFavorite ? 'text-red-600 bg-red-50 shadow-md' : 'text-gray-400 hover:text-red-600 hover:bg-red-50 hover:shadow-md' }}">
                                    <i class="fas fa-heart text-2xl sm:text-3xl {{ $isFavorite ? 'fas' : 'far' }}"></i>
                                </button>
                            @endauth
                        </div>
                    </div>
                </div>

                <!-- Location -->
                @if($ad->location_country || $ad->location_city || $ad->location_district || $ad->location_address)
                    <div class="bg-blue-50 rounded-lg p-4 mb-4 border border-blue-100">
                        <div class="flex items-start gap-3">
                            <div class="bg-primary/10 p-2 rounded-lg">
                                <i class="fas fa-map-marker-alt text-primary text-lg"></i>
                            </div>
                            <div class="flex-1">
                                <div class="font-semibold text-gray-800 mb-2 text-sm">{{ __('frontend.ads.location') }}:</div>
                                <div class="text-gray-700 space-y-1">
                                    @if($ad->location_address)
                                        <div class="font-medium">{{ $ad->location_address }}</div>
                                    @endif
                                    @if($ad->location_district || $ad->location_city || $ad->location_country)
                                        <div class="text-sm flex items-center gap-1 flex-wrap">
                                            @if($ad->location_district)
                                                <span class="bg-white px-2 py-1 rounded">{{ $ad->location_district }}</span>
                                            @endif
                                            @if($ad->location_city)
                                                <span class="bg-white px-2 py-1 rounded">{{ $ad->location_city }}</span>
                                            @endif
                                            @if($ad->location_country)
                                                <span class="bg-white px-2 py-1 rounded font-semibold">
                                                    @if($ad->location_country === 'SY')
                                                        🇸🇾 سوريا
                                                    @elseif($ad->location_country === 'TR')
                                                        🇹🇷 تركيا
                                                    @else
                                                        {{ $ad->location_country }}
                                                    @endif
                                                </span>
                                            @endif
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

                <!-- Meta Info -->
                <div class="flex flex-wrap items-center gap-4 sm:gap-6 text-sm text-gray-600 pt-4 border-t border-gray-200">
                    <span class="flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-lg">
                        <i class="fas fa-eye text-primary"></i>
                        <span class="font-semibold">{{ number_format($ad->views_count) }}</span>
                        <span class="text-gray-500">{{ __('frontend.ads.views') }}</span>
                    </span>
                    @if($ad->published_at)
                        <span class="flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-lg">
                            <i class="fas fa-clock text-primary"></i>
                            <span>{{ __('frontend.ads.posted') }}:</span>
                            <span class="font-semibold">{{ $ad->published_at->diffForHumans() }}</span>
                        </span>
                    @endif
                    @if($ad->category)
                        <span class="flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-lg">
                            <i class="fas fa-tag text-primary"></i>
                            <span class="font-semibold">{{ $ad->category->getName(app()->getLocale()) }}</span>
                        </span>
                    @endif
                </div>
            </div>

            <!-- Images Gallery with Lightbox -->
            @php
                $images = is_array($ad->images) ? $ad->images : (is_string($ad->images) ? json_decode($ad->images, true) : []);
                $images = $images ?? [];
            @endphp
            @if(!empty($images) && is_array($images) && count($images) > 0)
                <div class="bg-white rounded-xl shadow-lg p-4 sm:p-6 mb-6 overflow-hidden">
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-xl sm:text-2xl font-bold text-gray-800 flex items-center gap-2">
                            <i class="fas fa-images text-primary"></i>
                            {{ __('frontend.ads.images') }} <span class="text-gray-500 text-lg">({{ count($images) }})</span>
                        </h2>
                    </div>
                    
                    <!-- Main Image Display -->
                    <div class="mb-4">
                        <div class="relative bg-gray-100 rounded-xl overflow-hidden" style="aspect-ratio: 16/9;">
                            <img id="main-image" 
                                 src="{{ asset('storage/' . (is_string($images[0]) ? $images[0] : (is_array($images[0]) ? ($images[0]['path'] ?? $images[0]) : ''))) }}"
                                 alt="{{ $ad->title }}"
                                 class="w-full h-full object-contain cursor-zoom-in transition-transform duration-300 hover:scale-105"
                                 onclick="openLightbox(0)">
                            @if(count($images) > 1)
                                <button onclick="changeMainImage(-1)" class="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition">
                                    <i class="fas fa-chevron-left"></i>
                                </button>
                                <button onclick="changeMainImage(1)" class="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition">
                                    <i class="fas fa-chevron-right"></i>
                                </button>
                            @endif
                        </div>
                    </div>
                    
                    <!-- Thumbnail Gallery -->
                    @if(count($images) > 1)
                        <div class="grid grid-cols-4 sm:grid-cols-6 gap-2 sm:gap-3">
                            @foreach($images as $index => $image)
                                @php
                                    $imagePath = is_string($image) ? $image : (is_array($image) ? ($image['path'] ?? $image) : '');
                                @endphp
                                @if($imagePath)
                                    <div class="relative group cursor-pointer" onclick="changeMainImageTo({{ $index }})">
                                        <img src="{{ asset('storage/' . $imagePath) }}"
                                             alt="{{ $ad->title }} - {{ $index + 1 }}"
                                             class="w-full h-20 sm:h-24 object-cover rounded-lg border-2 transition-all duration-300 {{ $index === 0 ? 'border-primary shadow-md' : 'border-transparent hover:border-primary' }}"
                                             onerror="this.style.display='none';">
                                        <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 rounded-lg transition"></div>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    @endif
                </div>
            @endif

            <!-- Description -->
            <div class="bg-white rounded-xl shadow-lg p-6 mb-6 border border-gray-100">
                <div class="flex items-center gap-3 mb-4 pb-3 border-b border-gray-200">
                    <div class="bg-primary/10 p-2 rounded-lg">
                        <i class="fas fa-align-right text-primary"></i>
                    </div>
                    <h2 class="text-xl sm:text-2xl font-bold text-gray-800">{{ __('frontend.ads.description') }}</h2>
                </div>
                <div class="text-gray-700 whitespace-pre-line leading-relaxed text-base sm:text-lg">{{ $ad->description }}</div>
            </div>

            <!-- Custom Fields -->
            @if($ad->custom_fields && $ad->category->custom_fields)
                @php
                    $categoryFields = $ad->category->custom_fields ?? [];
                    $adCustomFields = $ad->custom_fields;
                @endphp
                @if($categoryFields && $adCustomFields)
                    <div class="bg-white rounded-xl shadow-lg p-6 mb-6 border border-gray-100">
                        <div class="flex items-center gap-3 mb-4 pb-3 border-b border-gray-200">
                            <div class="bg-primary/10 p-2 rounded-lg">
                                <i class="fas fa-list-ul text-primary"></i>
                            </div>
                            <h2 class="text-xl sm:text-2xl font-bold text-gray-800">{{ __('frontend.ads.details') }}</h2>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            @foreach($categoryFields as $field)
                                @if(isset($adCustomFields[$field['id']]))
                                    <div class="bg-gray-50 rounded-lg p-4 border border-gray-100 hover:shadow-md transition">
                                        <div class="text-xs text-gray-500 mb-1 font-medium">{{ $field['label'][app()->getLocale()] ?? $field['label']['ar'] }}</div>
                                        <div class="text-gray-800 font-semibold text-base">
                                            @if($field['type'] === 'select')
                                                @php
                                                    $option = collect($field['options'])->firstWhere('id', $adCustomFields[$field['id']]);
                                                @endphp
                                                {{ $option ? ($option[app()->getLocale()] ?? $option['ar']) : $adCustomFields[$field['id']] }}
                                            @else
                                                {{ $adCustomFields[$field['id']] }}
                                            @endif
                                        </div>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                @endif
            @endif
        </main>

        <!-- Sidebar -->
        <aside class="lg:col-span-1">
            <!-- Actions -->
            <div class="space-y-6">
                <!-- Contact Seller -->
                <div class="bg-gradient-to-br from-white to-gray-50 rounded-xl shadow-lg p-6 border border-gray-100">
                    <div class="flex items-center gap-3 mb-4 pb-3 border-b border-gray-200">
                        <div class="bg-primary/10 p-2 rounded-lg">
                            <i class="fas fa-user-circle text-primary"></i>
                        </div>
                        <h3 class="font-bold text-gray-800 text-lg">{{ __('frontend.ads.contact_seller') }}</h3>
                    </div>
                    @if($ad->user)
                        <div class="space-y-3">
                            <div>
                                <span class="text-sm text-gray-500">{{ __('frontend.nav.profile') }}:</span>
                                <a href="{{ route('seller.show', $ad->user->slug) }}" class="font-semibold text-gray-800 hover:text-primary transition flex items-center gap-2">
                                    {{ $ad->user->name }}
                                    @if($ad->user->is_verified)
                                        <span class="px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-xs font-semibold flex items-center gap-1">
                                            <i class="fas fa-check-circle"></i>
                                            {{ __('frontend.profile.verified') }}
                                        </span>
                                    @endif
                                </a>
                            </div>
                            @php
                                $displayPhone = $ad->user->business_phone ?? $ad->user->phone;
                                $whatsAppNumber = $displayPhone ? preg_replace('/[^0-9+]/', '', $displayPhone) : null;
                            @endphp
                            @if($whatsAppNumber)
                                <a href="https://wa.me/{{ ltrim($whatsAppNumber, '+') }}" 
                                   target="_blank" 
                                   class="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white w-full block text-center py-3.5 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                                    <i class="fab fa-whatsapp text-xl"></i>
                                    {{ __('frontend.seller.whatsapp_contact') }}
                                </a>
                            @elseif($displayPhone)
                                <a href="tel:{{ $displayPhone }}"
                                   class="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white w-full block text-center py-3.5 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
                                   title="{{ $displayPhone }}">
                                    <i class="fas fa-phone text-xl"></i>
                                    <span>{{ __('frontend.seller.call') }}</span>
                                </a>
                            @endif
                            
                            @auth
                                @if(Auth::id() != $ad->user->id)
                                    @if(Auth::user()->hasBlocked($ad->user->id))
                                        <form action="{{ route('profile.blocked-users.unblock', $ad->user->id) }}" method="POST" class="mt-3">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" 
                                                    onclick="return confirm('{{ __('frontend.profile.confirm_unblock') }}')"
                                                    class="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition flex items-center justify-center gap-2">
                                                <i class="fas fa-unlock"></i>
                                                {{ __('frontend.profile.unblock') }}
                                            </button>
                                        </form>
                                    @else
                                        <form action="{{ route('profile.blocked-users.block', $ad->user->id) }}" method="POST" class="mt-3">
                                            @csrf
                                            <button type="submit" 
                                                    onclick="return confirm('{{ __('frontend.profile.confirm_block') }}')"
                                                    class="w-full bg-red-500 hover:bg-red-600 text-white py-2 px-4 rounded-lg transition flex items-center justify-center gap-2">
                                                <i class="fas fa-ban"></i>
                                                {{ __('frontend.profile.block_user') }}
                                            </button>
                                        </form>
                                    @endif
                                @endif
                            @endauth
                        </div>
                    @endif
                </div>

                <!-- Action Buttons -->
                <div class="bg-white rounded-xl shadow-lg p-6 border border-gray-100 space-y-3">
                    @auth
                        <button id="favorite-btn"
                                data-uid="{{ $ad->uid }}"
                                class="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl transition-all duration-300 {{ $isFavorite ? 'bg-red-50 text-red-600 hover:bg-red-100 border-2 border-red-200' : 'bg-gray-50 text-gray-600 hover:bg-gray-100 border-2 border-gray-200' }} font-semibold">
                            <i class="fas fa-heart {{ $isFavorite ? 'fas' : 'far' }} text-lg"></i>
                            <span id="favorite-text">{{ $isFavorite ? __('frontend.favorites.remove') : __('frontend.favorites.add') }}</span>
                        </button>
                    @endauth
                    
                    @auth
                        @if($ad->user_id !== Auth::id() && $ad->price)
                            <a href="{{ route('negotiations.create', $ad->uid) }}"
                               class="w-full block text-center py-3.5 rounded-xl bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-semibold transition-all duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 flex items-center justify-center gap-2">
                                <i class="fas fa-handshake"></i>
                                {{ __('frontend.negotiations.negotiate_price') }}
                            </a>
                        @endif
                    @else
                        @if($ad->price)
                            <a href="{{ route('login') }}"
                               class="w-full block text-center py-3.5 rounded-xl bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-semibold transition-all duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 flex items-center justify-center gap-2">
                                <i class="fas fa-handshake"></i>
                                {{ __('frontend.negotiations.negotiate_price') }}
                            </a>
                        @endif
                    @endauth
                    
                    @auth
                        @if($ad->user_id !== Auth::id())
                            <form action="{{ route('messages.create', $ad->uid) }}" method="POST">
                                @csrf
                                <button type="submit" class="btn-primary w-full py-3.5 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-300 flex items-center justify-center gap-2 font-semibold">
                                    <i class="fas fa-comments"></i>
                                    {{ __('frontend.messages.chat_with_seller') }}
                                </button>
                            </form>
                        @endif
                    @else
                        <a href="{{ route('login') }}" class="btn-primary w-full block text-center py-3.5 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-300 flex items-center justify-center gap-2 font-semibold">
                            <i class="fas fa-comments"></i>
                            {{ __('frontend.messages.chat_with_seller') }}
                        </a>
                    @endauth
                    
                    @auth
                        <a href="{{ route('profile.reports.create', ['ad_id' => $ad->id]) }}"
                           class="w-full block text-center py-3 rounded-xl border-2 border-red-300 text-red-600 hover:bg-red-50 transition-all duration-300 flex items-center justify-center gap-2 font-semibold">
                            <i class="fas fa-flag"></i>
                            {{ __('frontend.ads.report_ad') }}
                        </a>
                    @endauth
                </div>
            </div>

            <!-- Related Ads -->
            @if($relatedAds->count() > 0)
                <div class="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
                    <div class="flex items-center gap-3 mb-4 pb-3 border-b border-gray-200">
                        <div class="bg-primary/10 p-2 rounded-lg">
                            <i class="fas fa-th-large text-primary"></i>
                        </div>
                        <h3 class="font-bold text-gray-800 text-lg">{{ __('frontend.ads.related_ads') }}</h3>
                    </div>
                    <div class="space-y-3">
                        @foreach($relatedAds as $relatedAd)
                            <a href="{{ route('ads.show', $relatedAd->uid) }}" class="block group">
                                <div class="flex gap-3 p-2 rounded-lg hover:bg-gray-50 transition-all duration-300 border border-transparent hover:border-primary/20">
                                    @php
                                        $relatedImages = is_array($relatedAd->images) ? $relatedAd->images : (is_string($relatedAd->images) ? json_decode($relatedAd->images, true) : []);
                                        $relatedImages = $relatedImages ?? [];
                                        $firstRelatedImage = !empty($relatedImages) && is_array($relatedImages) ? $relatedImages[0] : null;
                                        $firstRelatedImagePath = is_string($firstRelatedImage) ? $firstRelatedImage : (is_array($firstRelatedImage) ? ($firstRelatedImage['path'] ?? $firstRelatedImage) : '');
                                    @endphp
                                    @if($firstRelatedImagePath)
                                        <img src="{{ asset('storage/' . $firstRelatedImagePath) }}"
                                             alt="{{ $relatedAd->title }}"
                                             class="w-20 h-20 object-cover rounded-lg shadow-md group-hover:shadow-lg transition">
                                    @else
                                        <div class="w-20 h-20 bg-gray-200 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-image text-gray-400"></i>
                                        </div>
                                    @endif
                                    <div class="flex-1 min-w-0">
                                        <h4 class="font-semibold text-sm text-gray-800 line-clamp-2 mb-1 group-hover:text-primary transition">
                                            {{ $relatedAd->title }}
                                        </h4>
                                        @if($relatedAd->price)
                                            <p class="text-primary font-bold text-sm">
                                                {{ format_price($relatedAd->price, 0, $relatedAd->currency) }}
                                            </p>
                                        @endif
                                    </div>
                                </div>
                            </a>
                        @endforeach
                    </div>
                </div>
            @endif
        </aside>
    </div>
</div>

@auth
<script>
document.addEventListener('DOMContentLoaded', function() {
    const favoriteBtn = document.getElementById('favorite-btn');
    const favoriteBtnMobile = document.getElementById('favorite-btn-mobile');
    const favoriteText = document.getElementById('favorite-text');

    function toggleFavorite(btn) {
        const uid = btn.getAttribute('data-uid');

        fetch(`{{ route('favorites.toggle', ':uid') }}`.replace(':uid', uid), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update desktop button
                if (favoriteBtn) {
                    if (data.is_favorite) {
                        favoriteBtn.classList.remove('bg-gray-50', 'text-gray-600', 'hover:bg-gray-100', 'border-gray-200');
                        favoriteBtn.classList.add('bg-red-50', 'text-red-600', 'hover:bg-red-100', 'border-red-200');
                        favoriteBtn.querySelector('i').classList.remove('far');
                        favoriteBtn.querySelector('i').classList.add('fas');
                    } else {
                        favoriteBtn.classList.remove('bg-red-50', 'text-red-600', 'hover:bg-red-100', 'border-red-200');
                        favoriteBtn.classList.add('bg-gray-50', 'text-gray-600', 'hover:bg-gray-100', 'border-gray-200');
                        favoriteBtn.querySelector('i').classList.remove('fas');
                        favoriteBtn.querySelector('i').classList.add('far');
                    }
                    if (favoriteText) {
                        favoriteText.textContent = data.is_favorite ? '{{ __('frontend.favorites.remove') }}' : '{{ __('frontend.favorites.add') }}';
                    }
                }

                // Update mobile button
                if (favoriteBtnMobile) {
                    if (data.is_favorite) {
                        favoriteBtnMobile.classList.remove('text-gray-400', 'hover:text-red-600', 'hover:bg-red-50');
                        favoriteBtnMobile.classList.add('text-red-600', 'bg-red-50', 'shadow-md');
                    } else {
                        favoriteBtnMobile.classList.remove('text-red-600', 'bg-red-50', 'shadow-md');
                        favoriteBtnMobile.classList.add('text-gray-400', 'hover:text-red-600', 'hover:bg-red-50');
                        favoriteBtnMobile.querySelector('i').classList.remove('fas');
                        favoriteBtnMobile.querySelector('i').classList.add('far');
                    }
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }

    if (favoriteBtn) {
        favoriteBtn.addEventListener('click', function() {
            toggleFavorite(this);
        });
    }

    if (favoriteBtnMobile) {
        favoriteBtnMobile.addEventListener('click', function() {
            toggleFavorite(this);
        });
    }
});

// Image Gallery Functions
let currentImageIndex = 0;
const images = @json(array_map(function($img) {
    return is_string($img) ? $img : (is_array($img) ? ($img['path'] ?? $img) : '');
}, $images ?? []));

function changeMainImage(direction) {
    currentImageIndex += direction;
    if (currentImageIndex < 0) currentImageIndex = images.length - 1;
    if (currentImageIndex >= images.length) currentImageIndex = 0;
    updateMainImage();
    updateThumbnails();
}

function changeMainImageTo(index) {
    currentImageIndex = index;
    updateMainImage();
    updateThumbnails();
}

function updateMainImage() {
    const mainImg = document.getElementById('main-image');
    if (mainImg && images[currentImageIndex]) {
        mainImg.src = '{{ asset("storage/") }}/' + images[currentImageIndex];
    }
}

function updateThumbnails() {
    document.querySelectorAll('.thumbnail-item').forEach((el, index) => {
        if (index === currentImageIndex) {
            el.classList.remove('border-transparent');
            el.classList.add('border-primary', 'shadow-md');
        } else {
            el.classList.remove('border-primary', 'shadow-md');
            el.classList.add('border-transparent');
        }
    });
}

function openLightbox(index) {
    currentImageIndex = index;
    // Simple lightbox implementation
    const lightbox = document.createElement('div');
    lightbox.className = 'fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4';
    lightbox.innerHTML = `
        <div class="relative max-w-7xl max-h-full">
            <button onclick="this.closest('.fixed').remove()" class="absolute top-4 right-4 text-white text-4xl hover:text-gray-300 z-10">×</button>
            <img src="{{ asset('storage/') }}/${images[currentImageIndex]}" class="max-w-full max-h-[90vh] object-contain">
            ${images.length > 1 ? `
                <button onclick="changeLightboxImage(-1)" class="absolute left-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-3 rounded-full">‹</button>
                <button onclick="changeLightboxImage(1)" class="absolute right-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-3 rounded-full">›</button>
            ` : ''}
        </div>
    `;
    document.body.appendChild(lightbox);
    
    window.changeLightboxImage = function(direction) {
        currentImageIndex += direction;
        if (currentImageIndex < 0) currentImageIndex = images.length - 1;
        if (currentImageIndex >= images.length) currentImageIndex = 0;
        lightbox.querySelector('img').src = '{{ asset("storage/") }}/' + images[currentImageIndex];
    };
    
    lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) lightbox.remove();
    });
}
</script>
@endauth
@endsection

