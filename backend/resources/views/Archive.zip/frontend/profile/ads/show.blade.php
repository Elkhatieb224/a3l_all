@extends('frontend.layouts.app')

@section('title', $ad->title)

@section('content')
<div class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <div class="flex flex-col lg:flex-row gap-4 lg:gap-6">
            @include('frontend.profile.partials.sidebar')

            <!-- Main Content -->
            <main class="flex-1">
                <div class="bg-white rounded-lg shadow-md p-4 sm:p-6">
                    <!-- Header -->
                    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 pb-6 border-b border-gray-200">
                        <div class="flex-1">
                            <h1 class="text-2xl font-bold text-primary mb-2">{{ $ad->title }}</h1>
                            <div class="flex items-center gap-3 flex-wrap">
                                <span class="px-3 py-1 rounded-full text-sm font-semibold
                                    {{ $ad->status === 'active' ? 'bg-green-100 text-green-700' :
                                       ($ad->status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                                       ($ad->status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700')) }}">
                                    {{ __('frontend.profile.my_ads_management.status.' . $ad->status) }}
                                </span>
                                <span class="text-sm text-gray-500">UID: {{ $ad->uid }}</span>
                            </div>
                        </div>
                        <div class="flex items-center gap-2 mt-4 sm:mt-0">
                            <a href="{{ route('profile.ads.stats', $ad->uid) }}" 
                               class="px-4 py-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-lg text-sm transition">
                                <i class="fas fa-chart-bar ml-2"></i> {{ __('frontend.profile.my_ads_management.stats') }}
                            </a>
                            <a href="{{ route('profile.ads.edit', $ad->uid) }}" 
                               class="px-4 py-2 bg-yellow-50 text-yellow-600 hover:bg-yellow-100 rounded-lg text-sm transition">
                                <i class="fas fa-edit ml-2"></i> {{ __('frontend.edit') }}
                            </a>
                        </div>
                    </div>

                    <!-- Images -->
                    @php
                        $images = is_array($ad->images) ? $ad->images : (is_string($ad->images) ? json_decode($ad->images, true) : []);
                        $images = $images ?? [];
                    @endphp
                    @if(!empty($images) && is_array($images) && count($images) > 0)
                        <div class="mb-6">
                            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                                @foreach($images as $image)
                                    @php
                                        $imagePath = is_string($image) ? $image : (is_array($image) ? ($image['path'] ?? $image) : '');
                                    @endphp
                                    @if($imagePath)
                                        <img src="{{ asset('storage/' . $imagePath) }}" 
                                             alt="{{ $ad->title }}"
                                             class="w-full h-48 object-cover rounded-lg"
                                             onerror="this.style.display='none';">
                                    @endif
                                @endforeach
                            </div>
                        </div>
                    @endif

                    <!-- Details -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <!-- Price -->
                        @if($ad->price)
                            <div class="bg-gray-50 rounded-lg p-4">
                                <h3 class="text-sm font-semibold text-gray-600 mb-2">{{ __('frontend.ads.price') }}</h3>
                                <p class="text-2xl font-bold text-primary">{{ format_price($ad->price, 0, $ad->currency) }}</p>
                            </div>
                        @endif

                        <!-- Category -->
                        <div class="bg-gray-50 rounded-lg p-4">
                            <h3 class="text-sm font-semibold text-gray-600 mb-2">{{ __('frontend.ads.category') }}</h3>
                            <p class="text-gray-800">{{ $ad->category->name }}</p>
                            @if($ad->subcategory)
                                <p class="text-sm text-gray-600 mt-1">{{ $ad->subcategory->name }}</p>
                            @endif
                        </div>

                        <!-- Views -->
                        <div class="bg-gray-50 rounded-lg p-4">
                            <h3 class="text-sm font-semibold text-gray-600 mb-2">{{ __('frontend.profile.my_ads_management.views') }}</h3>
                            <p class="text-2xl font-bold text-primary">{{ $ad->views_count }}</p>
                        </div>

                        <!-- Published Date -->
                        <div class="bg-gray-50 rounded-lg p-4">
                            <h3 class="text-sm font-semibold text-gray-600 mb-2">{{ __('frontend.profile.my_ads_management.published_at') }}</h3>
                            <p class="text-gray-800">{{ $ad->created_at->format('Y-m-d H:i') }}</p>
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="mb-6">
                        <h3 class="text-lg font-bold text-primary mb-3">{{ __('frontend.ads.description') }}</h3>
                        <p class="text-gray-700 whitespace-pre-wrap">{{ $ad->description }}</p>
                    </div>

                    <!-- Custom Fields -->
                    @if($ad->custom_fields && count($ad->custom_fields) > 0)
                        <div class="mb-6">
                            <h3 class="text-lg font-bold text-primary mb-3">{{ __('frontend.profile.my_ads_management.additional_info') }}</h3>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                @foreach($ad->custom_fields as $key => $value)
                                    @if($value)
                                        <div class="bg-gray-50 rounded-lg p-4">
                                            <h4 class="text-sm font-semibold text-gray-600 mb-1">{{ $key }}</h4>
                                            <p class="text-gray-800">{{ $value }}</p>
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                        </div>
                    @endif

                    <!-- Rejection Reason -->
                    @if($ad->status === 'rejected' && $ad->rejection_reason)
                        <div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                            <h3 class="text-lg font-bold text-red-700 mb-2">{{ __('frontend.profile.my_ads_management.rejection_reason') }}</h3>
                            <p class="text-red-600">{{ $ad->rejection_reason }}</p>
                        </div>
                    @endif

                    <!-- Actions -->
                    <div class="flex items-center gap-2 pt-6 border-t border-gray-200">
                        <a href="{{ route('ads.show', $ad->uid) }}" 
                           class="px-4 py-2 bg-primary text-white hover:bg-blue-700 rounded-lg text-sm transition">
                            <i class="fas fa-external-link-alt ml-2"></i> {{ __('frontend.profile.my_ads_management.view_public') }}
                        </a>
                        <a href="{{ route('profile.ads.index') }}" 
                           class="px-4 py-2 bg-gray-100 text-gray-700 hover:bg-gray-200 rounded-lg text-sm transition">
                            <i class="fas fa-arrow-right ml-2"></i> {{ __('frontend.back') }}
                        </a>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>
@endsection

