@extends('frontend.layouts.app')

@section('title', __('frontend.profile.my_ads_management.edit_ad'))

@section('content')
<div class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <div class="flex flex-col lg:flex-row gap-4 lg:gap-6">
            @include('frontend.profile.partials.sidebar')

            <!-- Main Content -->
            <main class="flex-1">
                <div class="bg-white rounded-lg shadow-md p-4 sm:p-6">
                    <!-- Header -->
                    <div class="mb-6 pb-6 border-b border-gray-200">
                        <h1 class="text-2xl font-bold text-primary mb-2">{{ __('frontend.profile.my_ads_management.edit_ad') }}</h1>
                        <p class="text-gray-600 text-sm">{{ __('frontend.profile.my_ads_management.edit_ad_description') }}</p>
                    </div>

                    <!-- Pending Changes Notice -->
                    @if($ad->pending_changes)
                        <div class="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                            <div class="flex items-start gap-3">
                                <i class="fas fa-clock text-yellow-600 mt-1"></i>
                                <div class="flex-1">
                                    <h3 class="font-semibold text-yellow-800 mb-1">
                                        {{ __('frontend.profile.ads.changes_pending_review_title') }}
                                    </h3>
                                    <p class="text-sm text-yellow-700">
                                        {{ __('frontend.profile.ads.changes_pending_review_message') }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    @endif

                    <!-- Category Path -->
                    <div class="bg-gray-50 rounded-lg p-4 mb-6">
                        <div class="flex items-center gap-2 flex-wrap text-sm">
                            @if($ad->subcategory)
                                <span class="text-gray-700">{{ $ad->subcategory->getName(app()->getLocale()) }}</span>
                                <span class="text-gray-400"> < </span>
                            @endif
                            <span class="text-primary font-semibold">{{ $ad->category->getName(app()->getLocale()) }}</span>
                        </div>
                    </div>

                    <!-- Edit Form -->
                    <form action="{{ route('profile.ads.update', $ad->uid) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                        @csrf
                        @method('PUT')

                        <!-- Title -->
                        <div>
                            <label for="title" class="block text-sm font-semibold text-gray-700 mb-2">
                                {{ __('frontend.ads.title') }} <span class="text-red-500">*</span>
                            </label>
                            <input type="text" 
                                   name="title" 
                                   id="title" 
                                   value="{{ old('title', $ad->title) }}"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                   placeholder="{{ __('frontend.ads.title_placeholder') }}"
                                   required>
                            @error('title')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Description -->
                        <div>
                            <label for="description" class="block text-sm font-semibold text-gray-700 mb-2">
                                {{ __('frontend.ads.description') }} <span class="text-red-500">*</span>
                            </label>
                            <textarea name="description" 
                                      id="description" 
                                      rows="8" 
                                      class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                      placeholder="{{ __('frontend.ads.description_placeholder') }}"
                                      required>{{ old('description', $ad->description) }}</textarea>
                            @error('description')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Price -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="price" class="block text-sm font-semibold text-gray-700 mb-2">
                                    {{ __('frontend.ads.price') }} <span class="text-gray-500">({{ __('frontend.optional') }})</span>
                                </label>
                                <input type="number" 
                                       name="price" 
                                       id="price" 
                                       value="{{ old('price', $ad->price) }}"
                                       step="0.01"
                                       min="0"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                       placeholder="{{ __('frontend.ads.price_placeholder') }}">
                                @error('price')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label for="currency" class="block text-sm font-semibold text-gray-700 mb-2">
                                    {{ __('frontend.ads.currency') }}
                                </label>
                                <select name="currency" 
                                        id="currency"
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                                    <option value="SYP" {{ old('currency', $ad->currency ?? 'SYP') === 'SYP' ? 'selected' : '' }}>🇸🇾 الليرة السورية (SYP)</option>
                                    <option value="TRY" {{ old('currency', $ad->currency ?? 'SYP') === 'TRY' ? 'selected' : '' }}>🇹🇷 الليرة التركية (TRY)</option>
                                    <option value="USD" {{ old('currency', $ad->currency ?? 'SYP') === 'USD' ? 'selected' : '' }}>🇺🇸 الدولار الأمريكي (USD)</option>
                                    <option value="EUR" {{ old('currency', $ad->currency ?? 'SYP') === 'EUR' ? 'selected' : '' }}>🇪🇺 اليورو (EUR)</option>
                                </select>
                                @error('currency')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>

                        <!-- Custom Fields -->
                        @if(!empty($customFields))
                        <div class="border-t pt-6">
                            <h3 class="text-lg font-bold text-gray-800 mb-4">{{ __('frontend.ads.additional_details') }}</h3>
                            <div class="space-y-4">
                                @foreach($customFields as $field)
                                    @php
                                        $fieldId = $field['id'] ?? 'field_' . $loop->index;
                                        $fieldType = $field['type'] ?? 'text';
                                        $fieldLabel = $field['label'][app()->getLocale()] ?? $field['label']['ar'] ?? $fieldId;
                                        $isRequired = $field['required'] ?? false;
                                        $fieldValue = old($fieldId, $ad->custom_fields[$fieldId] ?? '');
                                    @endphp
                                    
                                    <div>
                                        <label for="{{ $fieldId }}" class="block text-sm font-semibold text-gray-700 mb-2">
                                            {{ $fieldLabel }}
                                            @if($isRequired)
                                                <span class="text-red-500">*</span>
                                            @endif
                                        </label>
                                        
                                        @if($fieldType === 'textarea')
                                            <textarea name="{{ $fieldId }}" 
                                                      id="{{ $fieldId }}" 
                                                      rows="4"
                                                      class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                                      @if($isRequired) required @endif>{{ $fieldValue }}</textarea>
                                        @elseif($fieldType === 'select' && isset($field['options']))
                                            <select name="{{ $fieldId }}" 
                                                    id="{{ $fieldId }}"
                                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                                    @if($isRequired) required @endif>
                                                <option value="">{{ __('frontend.ads.select_option') }}</option>
                                                @foreach($field['options'] as $option)
                                                    <option value="{{ $option[app()->getLocale()] ?? $option['ar'] ?? $option }}" 
                                                            {{ $fieldValue == ($option[app()->getLocale()] ?? $option['ar'] ?? $option) ? 'selected' : '' }}>
                                                        {{ $option[app()->getLocale()] ?? $option['ar'] ?? $option }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        @elseif($fieldType === 'number')
                                            <input type="number" 
                                                   name="{{ $fieldId }}" 
                                                   id="{{ $fieldId }}"
                                                   value="{{ $fieldValue }}"
                                                   step="{{ $field['step'] ?? 1 }}"
                                                   min="{{ $field['min'] ?? '' }}"
                                                   max="{{ $field['max'] ?? '' }}"
                                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                                   @if($isRequired) required @endif>
                                        @elseif($fieldType === 'checkbox')
                                            <div class="flex items-center gap-2">
                                                <input type="checkbox" 
                                                       name="{{ $fieldId }}" 
                                                       id="{{ $fieldId }}"
                                                       value="1"
                                                       {{ $fieldValue ? 'checked' : '' }}
                                                       class="w-5 h-5 text-primary border-gray-300 rounded focus:ring-primary">
                                                <label for="{{ $fieldId }}" class="text-sm text-gray-600">
                                                    {{ __('frontend.ads.yes') }}
                                                </label>
                                            </div>
                                        @else
                                            <input type="text" 
                                                   name="{{ $fieldId }}" 
                                                   id="{{ $fieldId }}"
                                                   value="{{ $fieldValue }}"
                                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                                                   @if($isRequired) required @endif>
                                        @endif
                                        
                                        @error($fieldId)
                                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                        @enderror
                                    </div>
                                @endforeach
                            </div>
                        </div>
                        @endif

                        <!-- Current Images -->
                        @if($ad->images && count($ad->images) > 0)
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">
                                    {{ __('frontend.profile.my_ads_management.current_images') }}
                                </label>
                                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                                    @foreach($ad->images as $image)
                                        <div class="relative">
                                            <img src="{{ asset('storage/' . $image) }}" 
                                                 alt="Current image"
                                                 class="w-full h-32 object-cover rounded-lg">
                                        </div>
                                    @endforeach
                                </div>
                                <p class="text-xs text-gray-500 mb-4">{{ __('frontend.profile.my_ads_management.replace_images_note') }}</p>
                            </div>
                        @endif

                        <!-- New Images -->
                        <div>
                            <label for="images" class="block text-sm font-semibold text-gray-700 mb-2">
                                {{ __('frontend.ads.images') }} <span class="text-gray-500">({{ __('frontend.optional') }})</span>
                            </label>
                            <input type="file" 
                                   name="images[]" 
                                   id="images" 
                                   multiple 
                                   accept="image/*"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                            <p class="text-xs text-gray-500 mt-2">
                                {{ __('frontend.ads.images_hint') }}
                            </p>
                            @error('images.*')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Preview Selected Images -->
                        <div id="images-preview" class="hidden">
                            <h3 class="text-sm font-semibold text-gray-700 mb-3">{{ __('frontend.ads.selected_images') }}:</h3>
                            <div id="images-list" class="grid grid-cols-2 md:grid-cols-4 gap-4"></div>
                        </div>

                        <!-- Buttons -->
                        <div class="flex items-center justify-between gap-4 pt-4 border-t">
                            <a href="{{ route('profile.ads.show', $ad->uid) }}" 
                               class="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-semibold">
                                <i class="fas fa-arrow-right ml-2"></i>
                                {{ __('frontend.cancel') }}
                            </a>
                            <button type="submit" class="btn-primary px-8 py-3 rounded-lg font-bold">
                                <i class="fas fa-save ml-2"></i>
                                {{ __('frontend.profile.my_ads_management.save_changes') }}
                            </button>
                        </div>
                    </form>
                </div>
            </main>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('images');
    const imagesPreview = document.getElementById('images-preview');
    const imagesList = document.getElementById('images-list');

    if (fileInput) {
        fileInput.addEventListener('change', function() {
            imagesList.innerHTML = '';
            
            if (this.files.length > 0) {
                imagesPreview.classList.remove('hidden');
                
                Array.from(this.files).forEach((file) => {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const imageItem = document.createElement('div');
                        imageItem.className = 'relative';
                        imageItem.innerHTML = `
                            <img src="${e.target.result}" 
                                 alt="${file.name}" 
                                 class="w-full h-32 object-cover rounded-lg">
                            <span class="absolute top-2 right-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
                                ${(file.size / 1024 / 1024).toFixed(2)} MB
                            </span>
                        `;
                        imagesList.appendChild(imageItem);
                    };
                    reader.readAsDataURL(file);
                });
            } else {
                imagesPreview.classList.add('hidden');
            }
        });
    }
});
</script>
@endsection

