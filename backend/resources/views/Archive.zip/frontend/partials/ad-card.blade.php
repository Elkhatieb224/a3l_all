<a href="{{ route('ads.show', $ad->uid) }}" class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md hover:border-secondary transition group">
    <!-- Image -->
    <div class="relative h-40 bg-gray-200 overflow-hidden">
        @php
            $images = is_array($ad->images) ? $ad->images : (is_string($ad->images) ? json_decode($ad->images, true) : []);
            $images = $images ?? [];
            $firstImage = !empty($images) && is_array($images) ? $images[0] : null;
            $firstImagePath = is_string($firstImage) ? $firstImage : (is_array($firstImage) ? ($firstImage['path'] ?? $firstImage) : '');
        @endphp
        @if($firstImagePath)
            <img src="{{ asset('storage/' . $firstImagePath) }}" 
                 alt="{{ $ad->title }}"
                 class="w-full h-full object-contain group-hover:scale-110 transition duration-300"
                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <div class="w-full h-full hidden items-center justify-center bg-gray-100">
                <i class="fas fa-image text-gray-400 text-4xl"></i>
            </div>
        @else
            <div class="w-full h-full flex items-center justify-center bg-gray-100">
                <i class="fas fa-image text-gray-400 text-4xl"></i>
            </div>
        @endif
        
        <!-- Badges -->
        <div class="absolute top-2 {{ app()->getLocale() === 'ar' ? 'right-2' : 'left-2' }} flex flex-col gap-2">
            @if($ad->is_featured)
                <span class="bg-secondary text-primary px-2 py-1 rounded text-xs font-bold">
                    <i class="fas fa-star"></i> {{ __('frontend.ads.featured') }}
                </span>
            @endif
            @if($ad->is_urgent)
                <span class="bg-red-500 text-white px-2 py-1 rounded text-xs font-bold">
                    <i class="fas fa-exclamation-circle"></i> {{ __('frontend.ads.urgent') }}
                </span>
            @endif
        </div>
    </div>

    <!-- Content -->
    <div class="p-3">
        <h3 class="font-semibold text-gray-800 mb-1 line-clamp-2 group-hover:text-primary transition text-sm leading-tight">
            {{ $ad->title }}
        </h3>
        
        <!-- Price -->
        @if($ad->price)
            <div class="text-lg font-bold text-primary mb-1">
                {{ format_price($ad->price, 0, $ad->currency) }}
            </div>
        @endif

        <!-- Location -->
        @if($ad->location_city)
            <div class="flex items-center gap-1 text-xs text-gray-600 mb-1">
                <i class="fas fa-map-marker-alt text-gray-400"></i>
                <span class="truncate">{{ $ad->location_city }}</span>
            </div>
        @endif

        <!-- Meta -->
        <div class="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-gray-100">
            <span class="flex items-center gap-1">
                <i class="fas fa-eye text-gray-400"></i>
                {{ $ad->views_count }}
            </span>
            @if($ad->published_at)
                <span class="text-gray-400">
                    {{ $ad->published_at->diffForHumans() }}
                </span>
            @endif
        </div>
    </div>
</a>

