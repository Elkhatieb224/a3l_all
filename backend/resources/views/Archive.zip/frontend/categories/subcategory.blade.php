@extends('frontend.layouts.app')

@section('title', $subcategory->getName(app()->getLocale()))

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Breadcrumb -->
    <nav class="mb-6 text-sm">
        <ol class="flex items-center gap-2 text-gray-600">
            <li><a href="{{ route('home') }}" class="hover:text-primary">{{ __('frontend.nav.home') }}</a></li>
            <li><i class="fas fa-chevron-left text-xs"></i></li>
            <li><a href="{{ route('categories.index') }}" class="hover:text-primary">{{ __('frontend.categories.title') }}</a></li>
            <li><i class="fas fa-chevron-left text-xs"></i></li>
            <li><a href="{{ route('categories.show', $category->slug) }}" class="hover:text-primary">
                {{ $category->getName(app()->getLocale()) }}
            </a></li>
            <li><i class="fas fa-chevron-left text-xs"></i></li>
            <li class="text-gray-800 font-semibold">{{ $subcategory->getName(app()->getLocale()) }}</li>
        </ol>
    </nav>

    <!-- Subcategory Header -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <div class="flex items-center gap-4">
            @if($subcategory->icon)
                <img src="{{ asset('storage/' . $subcategory->icon) }}" 
                     alt="{{ $subcategory->getName(app()->getLocale()) }}"
                     class="w-16 h-16 object-contain">
            @else
                <div class="w-16 h-16 bg-primary rounded-lg flex items-center justify-center">
                    <i class="fas fa-folder text-secondary text-2xl"></i>
                </div>
            @endif
            <div>
                <h1 class="text-3xl font-bold text-gray-800 mb-2">
                    {{ $subcategory->getName(app()->getLocale()) }}
                </h1>
                @if($subcategory->getDescription(app()->getLocale()))
                    <p class="text-gray-600">{{ $subcategory->getDescription(app()->getLocale()) }}</p>
                @endif
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <!-- Sidebar - Children Subcategories -->
        @if($subcategory->children->count() > 0)
        <aside class="lg:col-span-1">
            <div class="bg-white rounded-lg shadow-md p-6 sticky top-20">
                <h3 class="font-bold text-gray-800 mb-4">
                    <i class="fas fa-list text-secondary ml-2"></i>
                    {{ __('frontend.categories.subcategories') }}
                </h3>
                <ul class="space-y-2">
                    @foreach($subcategory->children as $child)
                        <li>
                            <a href="{{ route('categories.subcategory', [$category->slug, $child->slug]) }}" 
                               class="flex items-center justify-between p-2 rounded hover:bg-gray-50 transition">
                                <span class="text-gray-700">{{ $child->getName(app()->getLocale()) }}</span>
                            </a>
                        </li>
                    @endforeach
                </ul>
            </div>
        </aside>
        @endif

        <!-- Main Content - Ads -->
        <main class="{{ $subcategory->children->count() > 0 ? 'lg:col-span-3' : 'lg:col-span-4' }}">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-2xl font-bold text-gray-800">
                    {{ __('frontend.ads.title') }} ({{ $ads->total() }})
                </h2>
            </div>

            @if($ads->count() > 0)
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    @foreach($ads as $ad)
                        @include('frontend.partials.ad-card', ['ad' => $ad])
                    @endforeach
                </div>

                <!-- Pagination -->
                <div class="mt-6">
                    {{ $ads->links() }}
                </div>
            @else
                <div class="bg-white rounded-lg shadow-md p-12 text-center">
                    <i class="fas fa-inbox text-gray-300 text-6xl mb-4"></i>
                    <p class="text-gray-500 text-lg">{{ __('frontend.ads.no_ads_found') }}</p>
                </div>
            @endif
        </main>
    </div>
</div>
@endsection

