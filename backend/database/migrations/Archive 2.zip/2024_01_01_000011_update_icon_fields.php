<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('categories', function (Blueprint $table) {
            $table->string('icon')->nullable()->comment('Path to icon image')->change();
        });

        Schema::table('subcategories', function (Blueprint $table) {
            $table->string('icon')->nullable()->comment('Path to icon image')->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('categories', function (Blueprint $table) {
            $table->string('icon')->nullable()->change();
        });

        Schema::table('subcategories', function (Blueprint $table) {
            $table->string('icon')->nullable()->change();
        });
    }
};

